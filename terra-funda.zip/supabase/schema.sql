-- Terra Funda: contas, salvamento e moderação no Supabase.
-- Como usar: no painel do Supabase, abra "SQL Editor", cole este arquivo inteiro e clique em "Run".
-- As regras de segurança (RLS) ficam no servidor: o jogo no navegador não consegue se dar poderes.

-- ============ Perfis ============
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 20),
  role text not null default 'player' check (role in ('player', 'moderator', 'admin')),
  banned_until timestamptz,
  ban_reason text,
  created_at timestamptz not null default now()
);
-- (se a tabela já existia de uma tentativa anterior, garante as colunas)
alter table public.profiles add column if not exists role text not null default 'player';
alter table public.profiles add column if not exists banned_until timestamptz;
alter table public.profiles add column if not exists ban_reason text;
alter table public.profiles add column if not exists created_at timestamptz not null default now();
-- Código público único de cada jogador (ex.: TF-7K2Q9M). É por ele que a equipe encontra e bane.
create or replace function public.novo_codigo() returns text language sql volatile as $$
  select 'TF-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6))
$$;
alter table public.profiles add column if not exists codigo text unique default public.novo_codigo();
update public.profiles set codigo = public.novo_codigo() where codigo is null;

-- Cria o perfil automaticamente no cadastro (o nome vem do formulário do jogo)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, username)
  values (new.id, coalesce(nullif(trim(new.raw_user_meta_data ->> 'username'), ''), 'jogador_' || substr(new.id::text, 1, 6)));
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Papel de quem está chamando (usado nas regras)
create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select coalesce((select role from public.profiles where id = auth.uid()), 'player')
$$;
create or replace function public.is_staff() returns boolean
language sql stable as $$ select public.my_role() in ('moderator', 'admin') $$;

alter table public.profiles enable row level security;

-- Cada um vê o próprio perfil; a equipe vê todos; jogadores comuns NÃO veem o administrador
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select using (
  auth.uid() is not null and (id = auth.uid() or public.is_staff() or role <> 'admin')
);
-- Só a equipe altera perfis (banir); papel só o admin muda (garantido pelo gatilho abaixo)
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update using (public.is_staff());

create or replace function public.guard_profile_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  -- sem usuário logado = comando direto no SQL Editor do dono do projeto (é assim que se nomeia o primeiro admin)
  if auth.uid() is null then return new; end if;
  if new.role is distinct from old.role and public.my_role() <> 'admin' then
    raise exception 'Só o administrador pode mudar cargos';
  end if;
  if old.role = 'admin' and public.my_role() <> 'admin' then
    raise exception 'Moderadores não podem alterar o administrador';
  end if;
  if new.id <> old.id then raise exception 'Operação inválida'; end if;
  return new;
end $$;
drop trigger if exists profiles_guard on public.profiles;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.guard_profile_update();

-- ============ Salvamento do jogo ============
create table if not exists public.saves (
  user_id uuid primary key references auth.users (id) on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.saves enable row level security;

create or replace function public.not_banned() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select banned_until is null or banned_until < now() from public.profiles where id = auth.uid()), false)
$$;

drop policy if exists saves_select on public.saves;
create policy saves_select on public.saves for select using (user_id = auth.uid() or public.is_staff());
drop policy if exists saves_insert on public.saves;
create policy saves_insert on public.saves for insert with check (user_id = auth.uid() and public.not_banned());
drop policy if exists saves_update on public.saves;
create policy saves_update on public.saves for update using (user_id = auth.uid() and public.not_banned());

-- ============ Registro de moderação ============
create table if not exists public.moderation_log (
  id bigint generated always as identity primary key,
  actor uuid references auth.users (id),
  target uuid references auth.users (id),
  action text not null,
  detail text,
  created_at timestamptz not null default now()
);
alter table public.moderation_log enable row level security;
drop policy if exists modlog_select on public.moderation_log;
create policy modlog_select on public.moderation_log for select using (public.my_role() = 'admin');
-- (só as funções abaixo escrevem no registro)

-- ============ Ações da equipe ============
-- Banir ou desbanir (moderador ou admin). dias = 0 desbane; dias < 0 = permanente.
create or replace function public.staff_ban(target uuid, dias int, motivo text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'Sem permissão'; end if;
  if (select role from profiles where id = target) = 'admin' then raise exception 'Não é possível banir o administrador'; end if;
  update profiles set
    banned_until = case when dias = 0 then null when dias < 0 then 'infinity'::timestamptz else now() + make_interval(days => dias) end,
    ban_reason = case when dias = 0 then null else motivo end
  where id = target;
  insert into moderation_log (actor, target, action, detail)
  values (auth.uid(), target, case when dias = 0 then 'desbanir' else 'banir' end, coalesce(motivo, '') || ' (' || dias || ' dias)');
end $$;

-- Nomear ou remover moderador (só admin)
create or replace function public.admin_set_role(target uuid, novo text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if public.my_role() <> 'admin' then raise exception 'Só o administrador'; end if;
  if novo not in ('player', 'moderator') then raise exception 'Cargo inválido'; end if;
  update profiles set role = novo where id = target and role <> 'admin';
  insert into moderation_log (actor, target, action, detail) values (auth.uid(), target, 'cargo', novo);
end $$;

-- Doar moedas (só admin, sem limite)
create or replace function public.admin_give_coins(target uuid, quantidade int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if public.my_role() <> 'admin' then raise exception 'Só o administrador'; end if;
  update saves set data = jsonb_set(data, '{coins}', to_jsonb(greatest(0, coalesce((data ->> 'coins')::int, 0) + quantidade))),
    updated_at = now()
  where user_id = target;
  insert into moderation_log (actor, target, action, detail) values (auth.uid(), target, 'moedas', quantidade::text);
end $$;

-- Lista para o painel (moderadores não veem o administrador). Busca por nome ou pelo código TF-XXXXXX.
drop function if exists public.staff_list_players(text);
create or replace function public.staff_list_players(busca text default '') returns table (
  id uuid, codigo text, username text, role text, banned_until timestamptz, ban_reason text, coins int, updated_at timestamptz
) language sql stable security definer set search_path = public as $$
  select p.id, p.codigo, p.username, p.role, p.banned_until, p.ban_reason,
         coalesce((s.data ->> 'coins')::int, 0), s.updated_at
  from profiles p left join saves s on s.user_id = p.id
  where public.is_staff()
    and (public.my_role() = 'admin' or p.role <> 'admin')
    and (p.username ilike '%' || coalesce(busca, '') || '%' or p.codigo ilike '%' || coalesce(busca, '') || '%')
  order by s.updated_at desc nulls last
  limit 100
$$;

-- ============ Permissões de acesso pela API ============
-- Alguns projetos novos do Supabase não liberam as tabelas criadas pelo SQL Editor para a API.
-- As regras (RLS) acima continuam valendo; isto só abre a porta para elas serem aplicadas.
grant usage on schema public to anon, authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update on public.saves to authenticated;
grant select on public.moderation_log to authenticated;

-- O próprio perfil (o jogo usa para saber nome, código e cargo de quem entrou)
create or replace function public.my_profile() returns setof public.profiles
language sql stable security definer set search_path = public as $$
  select * from public.profiles where id = auth.uid()
$$;
grant execute on function public.my_profile() to authenticated;
grant execute on function public.staff_ban(uuid, int, text) to authenticated;
grant execute on function public.admin_set_role(uuid, text) to authenticated;
grant execute on function public.admin_give_coins(uuid, int) to authenticated;
grant execute on function public.staff_list_players(text) to authenticated;

-- Dar nível de arma a um jogador (só admin). horas = 0: para sempre
create or replace function public.admin_bless(target uuid, arma text, nivel int, horas int) returns void language plpgsql security definer set search_path = public as $$ begin if public.my_role() <> 'admin' then raise exception 'Só o administrador'; end if; update saves set data = jsonb_set(data, '{wbless}', coalesce(data -> 'wbless', '{}'::jsonb) || jsonb_build_object(arma, jsonb_build_object('lv', nivel, 'ate', case when horas > 0 then floor(extract(epoch from now()) * 1000 + horas * 3600000)::bigint else null end))), updated_at = now() where user_id = target; insert into moderation_log (actor, target, action, detail) values (auth.uid(), target, 'bencao', arma || ' nivel ' || nivel || ' ' || horas || 'h'); end $$;
grant execute on function public.admin_bless(uuid, text, int, int) to authenticated;

-- Presentear uma skin: sai da conta de quem dá e vai para a de quem recebe (pelo código TF-XXXXXX)
create or replace function public.presentear_skin(codigo text, skin text) returns text language plpgsql security definer set search_path = public as $$ declare alvo uuid; nome text; begin if not public.not_banned() then raise exception 'Conta suspensa'; end if; select p.id, p.username into alvo, nome from profiles p where upper(p.codigo) = upper(presentear_skin.codigo); if alvo is null then raise exception 'Jogador não encontrado'; end if; if alvo = auth.uid() then raise exception 'Você não pode presentear a si mesmo'; end if; if not exists (select 1 from saves where user_id = auth.uid() and coalesce(data -> 'skins', '[]'::jsonb) ? skin) then raise exception 'Você não tem essa skin'; end if; if exists (select 1 from saves where user_id = alvo and coalesce(data -> 'skins', '[]'::jsonb) ? skin) then raise exception 'Esse jogador já tem essa skin'; end if; if not exists (select 1 from saves where user_id = alvo) then raise exception 'Esse jogador ainda não jogou'; end if; update saves set data = jsonb_set(data, '{skins}', coalesce((select jsonb_agg(v) from jsonb_array_elements(data -> 'skins') v where v <> to_jsonb(skin)), '[]'::jsonb)), updated_at = now() where user_id = auth.uid(); update saves set data = jsonb_set(data, '{skins}', coalesce(data -> 'skins', '[]'::jsonb) || to_jsonb(skin)), updated_at = now() where user_id = alvo; insert into moderation_log (actor, target, action, detail) values (auth.uid(), alvo, 'presente', skin); return nome; end $$;
grant execute on function public.presentear_skin(text, text) to authenticated;

-- Amigos do chat (as mensagens não ficam guardadas: passam ao vivo pelo Realtime)
create table if not exists public.amigos ( dono uuid not null references auth.users (id) on delete cascade, amigo uuid not null references auth.users (id) on delete cascade, criado timestamptz not null default now(), primary key (dono, amigo) );
alter table public.amigos enable row level security;
drop policy if exists amigos_select on public.amigos;
create policy amigos_select on public.amigos for select using (dono = auth.uid() or amigo = auth.uid());
create or replace function public.adicionar_amigo(codigo text) returns text language plpgsql security definer set search_path = public as $$ declare alvo uuid; nome text; begin if not public.not_banned() then raise exception 'Conta suspensa'; end if; select p.id, p.username into alvo, nome from profiles p where upper(p.codigo) = upper(adicionar_amigo.codigo) and p.role <> 'admin'; if alvo is null then raise exception 'Jogador não encontrado'; end if; if alvo = auth.uid() then raise exception 'Esse é o seu código'; end if; insert into amigos (dono, amigo) values (auth.uid(), alvo) on conflict do nothing; return nome; end $$;
create or replace function public.remover_amigo(alvo uuid) returns void language sql security definer set search_path = public as $$ delete from amigos where (dono = auth.uid() and amigo = alvo) or (dono = alvo and amigo = auth.uid()) $$;
create or replace function public.meus_amigos() returns table (id uuid, username text, codigo text, mutuo boolean, pediu boolean) language sql stable security definer set search_path = public as $$ select p.id, p.username, p.codigo, exists (select 1 from amigos a2 where a2.dono = p.id and a2.amigo = auth.uid()) and exists (select 1 from amigos a1 where a1.dono = auth.uid() and a1.amigo = p.id), not exists (select 1 from amigos a1 where a1.dono = auth.uid() and a1.amigo = p.id) from profiles p where p.id in (select amigo from amigos where dono = auth.uid() union select dono from amigos where amigo = auth.uid()) order by 4 desc, 2 $$;
grant select on public.amigos to authenticated;
grant execute on function public.adicionar_amigo(text) to authenticated;
grant execute on function public.remover_amigo(uuid) to authenticated;
grant execute on function public.meus_amigos() to authenticated;

-- Eventos do administrador: configuração do mundo (áreas seguras, eventos, fugitivo, vilas), presentes e fugitivo
create table if not exists public.mundo ( chave text primary key, valor jsonb not null, atualizado timestamptz not null default now() );
alter table public.mundo enable row level security;
drop policy if exists mundo_select on public.mundo;
create policy mundo_select on public.mundo for select using (auth.uid() is not null);
drop policy if exists mundo_admin on public.mundo;
create policy mundo_admin on public.mundo for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
grant select, insert, update, delete on public.mundo to authenticated;
create table if not exists public.presentes ( evento text not null, user_id uuid not null references auth.users (id) on delete cascade, n int not null default 0, primary key (evento, user_id) );
alter table public.presentes enable row level security;
drop policy if exists presentes_select on public.presentes;
create policy presentes_select on public.presentes for select using (user_id = auth.uid());
grant select on public.presentes to authenticated;
create or replace function public.pegar_presente(evento text, limite int) returns int language plpgsql security definer set search_path = public as $$ declare atual int; begin if not public.not_banned() then raise exception 'Conta suspensa'; end if; insert into presentes (evento, user_id, n) values (pegar_presente.evento, auth.uid(), 0) on conflict do nothing; select n into atual from presentes where presentes.evento = pegar_presente.evento and user_id = auth.uid() for update; if atual >= limite then return -1; end if; update presentes set n = n + 1 where presentes.evento = pegar_presente.evento and user_id = auth.uid(); return limite - atual - 1; end $$;
create or replace function public.pegar_fugitivo(evento text) returns boolean language plpgsql security definer set search_path = public as $$ declare nome text; v jsonb; begin if not public.not_banned() then raise exception 'Conta suspensa'; end if; select valor into v from mundo where chave = 'fugitivo' for update; if v is null or v ->> 'id' <> evento or (v ->> 'ganhador') is not null then return false; end if; select username into nome from profiles where id = auth.uid(); update mundo set valor = valor || jsonb_build_object('ganhador', nome), atualizado = now() where chave = 'fugitivo'; return true; end $$;
grant execute on function public.pegar_presente(text, int) to authenticated;
grant execute on function public.pegar_fugitivo(text) to authenticated;

-- ============ Primeiro administrador ============
-- Depois de criar a SUA conta pelo jogo, rode (trocando o nome):
--   update public.profiles set role = 'admin' where username = 'SEU_NOME_NO_JOGO';
