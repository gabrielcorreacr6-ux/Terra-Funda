-- Terra Funda: contas, salvamento e moderação no Supabase.
-- Como usar: no painel do Supabase, abra "SQL Editor", cole este arquivo inteiro e clique em "Run".
-- As regras de segurança (RLS) ficam no servidor: o jogo no navegador não consegue se dar poderes.

-- ============ Perfis ============
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 20),
  role text not null default 'player' check (role in ('player', 'moderator', 'admin')),
  banned_until timestamptz,
  ban_reason text,
  created_at timestamptz not null default now()
);
-- Código público único de cada jogador (ex.: TF-7K2Q9M). É por ele que a equipe encontra e bane.
create or replace function public.novo_codigo() returns text language sql volatile as $$
  select 'TF-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6))
$$;
alter table public.profiles add column if not exists codigo text unique default public.novo_codigo();
update public.profiles set codigo = public.novo_codigo() where codigo is null;

-- Cria o perfil automaticamente no cadastro (o nome vem do formulário do jogo)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, username)
  values (new.id, coalesce(nullif(trim(new.raw_user_meta_data ->> 'username'), ''), 'jogador_' || substr(new.id::text, 1, 6)));
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Papel de quem está chamando (usado nas regras)
create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select coalesce((select role from public.profiles where id = auth.uid()), 'player')
$$;
create or replace function public.is_staff() returns boolean
language sql stable as $$ select public.my_role() in ('moderator', 'admin') $$;

alter table public.profiles enable row level security;

-- Cada um vê o próprio perfil; a equipe vê todos; jogadores comuns NÃO veem o administrador
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select using (
  auth.uid() is not null and (id = auth.uid() or public.is_staff() or role <> 'admin')
);
-- Só a equipe altera perfis (banir); papel só o admin muda (garantido pelo gatilho abaixo)
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update using (public.is_staff());

create or replace function public.guard_profile_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  -- sem usuário logado = comando direto no SQL Editor do dono do projeto (é assim que se nomeia o primeiro admin)
  if auth.uid() is null then return new; end if;
  if new.role is distinct from old.role and public.my_role() <> 'admin' then
    raise exception 'Só o administrador pode mudar cargos';
  end if;
  if old.role = 'admin' and public.my_role() <> 'admin' then
    raise exception 'Moderadores não podem alterar o administrador';
  end if;
  if new.id <> old.id then raise exception 'Operação inválida'; end if;
  return new;
end $$;
drop trigger if exists profiles_guard on public.profiles;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.guard_profile_update();

-- ============ Salvamento do jogo ============
create table if not exists public.saves (
  user_id uuid primary key references auth.users (id) on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.saves enable row level security;

create or replace function public.not_banned() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select banned_until is null or banned_until < now() from public.profiles where id = auth.uid()), false)
$$;

drop policy if exists saves_select on public.saves;
create policy saves_select on public.saves for select using (user_id = auth.uid() or public.is_staff());
drop policy if exists saves_insert on public.saves;
create policy saves_insert on public.saves for insert with check (user_id = auth.uid() and public.not_banned());
drop policy if exists saves_update on public.saves;
create policy saves_update on public.saves for update using (user_id = auth.uid() and public.not_banned());

-- ============ Registro de moderação ============
create table if not exists public.moderation_log (
  id bigint generated always as identity primary key,
  actor uuid references auth.users (id),
  target uuid references auth.users (id),
  action text not null,
  detail text,
  created_at timestamptz not null default now()
);
alter table public.moderation_log enable row level security;
drop policy if exists modlog_select on public.moderation_log;
create policy modlog_select on public.moderation_log for select using (public.my_role() = 'admin');
-- (só as funções abaixo escrevem no registro)

-- ============ Ações da equipe ============
-- Banir ou desbanir (moderador ou admin). dias = 0 desbane; dias < 0 = permanente.
create or replace function public.staff_ban(target uuid, dias int, motivo text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'Sem permissão'; end if;
  if (select role from profiles where id = target) = 'admin' then raise exception 'Não é possível banir o administrador'; end if;
  update profiles set
    banned_until = case when dias = 0 then null when dias < 0 then 'infinity'::timestamptz else now() + make_interval(days => dias) end,
    ban_reason = case when dias = 0 then null else motivo end
  where id = target;
  insert into moderation_log (actor, target, action, detail)
  values (auth.uid(), target, case when dias = 0 then 'desbanir' else 'banir' end, coalesce(motivo, '') || ' (' || dias || ' dias)');
end $$;

-- Nomear ou remover moderador (só admin)
create or replace function public.admin_set_role(target uuid, novo text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if public.my_role() <> 'admin' then raise exception 'Só o administrador'; end if;
  if novo not in ('player', 'moderator') then raise exception 'Cargo inválido'; end if;
  update profiles set role = novo where id = target and role <> 'admin';
  insert into moderation_log (actor, target, action, detail) values (auth.uid(), target, 'cargo', novo);
end $$;

-- Doar moedas (só admin, sem limite)
create or replace function public.admin_give_coins(target uuid, quantidade int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if public.my_role() <> 'admin' then raise exception 'Só o administrador'; end if;
  update saves set data = jsonb_set(data, '{coins}', to_jsonb(greatest(0, coalesce((data ->> 'coins')::int, 0) + quantidade))),
    updated_at = now()
  where user_id = target;
  insert into moderation_log (actor, target, action, detail) values (auth.uid(), target, 'moedas', quantidade::text);
end $$;

-- Lista para o painel (moderadores não veem o administrador). Busca por nome ou pelo código TF-XXXXXX.
drop function if exists public.staff_list_players(text);
create or replace function public.staff_list_players(busca text default '') returns table (
  id uuid, codigo text, username text, role text, banned_until timestamptz, ban_reason text, coins int, updated_at timestamptz
) language sql stable security definer set search_path = public as $$
  select p.id, p.codigo, p.username, p.role, p.banned_until, p.ban_reason,
         coalesce((s.data ->> 'coins')::int, 0), s.updated_at
  from profiles p left join saves s on s.user_id = p.id
  where public.is_staff()
    and (public.my_role() = 'admin' or p.role <> 'admin')
    and (p.username ilike '%' || coalesce(busca, '') || '%' or p.codigo ilike '%' || coalesce(busca, '') || '%')
  order by s.updated_at desc nulls last
  limit 100
$$;

-- ============ Primeiro administrador ============
-- Depois de criar a SUA conta pelo jogo, rode (trocando o nome):
--   update public.profiles set role = 'admin' where username = 'SEU_NOME_NO_JOGO';
