"""Construções: muros, portões, torres, casas, fortalezas e móveis (folhas b_*.jpg em tools/sprites-src).
Chamado pelo build_atlas.py. Gera assets/estruturas.webp e o mapa ATLAS2 dentro do game.js.
As folhas novas têm fundo rosa ou magenta e linhas de grade escuras; aqui as linhas são apagadas
e cada peça é recortada pelos componentes conectados dentro de uma caixa (coordenadas da folha 2048 × 2048)."""
import os, json, re
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'tools', 'sprites-src')


def bg_of(a):
    q = (a[::7, ::7] // 8 * 8).reshape(-1, 3)
    u, c = np.unique(q, axis=0, return_counts=True)
    return u[c.argmax()].astype(int) + 4


def fg_mask(a):
    """Tudo que não é fundo, sem as linhas da grade (escuras, finas e com fundo dos dois lados)."""
    r, g, b = [a[..., k].astype(int) for k in range(3)]
    d = np.sqrt(((a.astype(int) - bg_of(a)) ** 2).sum(-1))
    bgm = ((r > 90) & (b > 90) & (g < 0.6 * np.minimum(r, b))) | (d < 48)
    lum = a.mean(-1)
    dark = (lum < 120) & ~bgm
    line = np.zeros_like(bgm)
    for ax in (0, 1):
        frac = dark.mean(axis=1 - ax)
        n = len(frac)
        for i in range(n):
            nb = min(frac[max(0, i - 9)], frac[min(n - 1, i + 9)])
            if frac[i] > 0.2 and frac[i] - nb > 0.15:
                for j in range(max(0, i - 4), min(n, i + 5)):
                    if ax == 0:
                        side = np.roll(bgm, 9, 0)[j] | np.roll(bgm, -9, 0)[j]
                        line[j] |= dark[j] & side
                    else:
                        side = np.roll(bgm, 9, 1)[:, j] | np.roll(bgm, -9, 1)[:, j]
                        line[:, j] |= dark[:, j] & side
    return ndi.binary_opening(~bgm & ~line, iterations=2), bgm


_cache = {}
def sheet(name):
    if name not in _cache:
        a = np.asarray(Image.open(os.path.join(SRC, name + '.jpg')).convert('RGB'))
        fg, bgm = fg_mask(a)
        _cache[name] = (a, fg, bgm)
    return _cache[name]


def pick(name, box, mode='largest', min_area=900, erase=None, unmix=None, open_extra=0, despill=False):
    """Recorta a peça dentro de box = (x0, y0, x1, y1). mode 'largest' fica com o maior pedaço,
    'all' junta todos os pedaços grandes. erase(xx, yy) -> máscara de pixels a apagar (coords da folha)."""
    a, fg, bgm = sheet(name)
    x0, y0, x1, y1 = box
    sub = fg[y0:y1, x0:x1].copy()
    bgm_sub = bgm[y0:y1, x0:x1]
    if erase is not None:
        yy, xx = np.mgrid[y0:y1, x0:x1]
        sub &= ~erase(xx, yy)
        sub = ndi.binary_opening(sub, iterations=2)
    if open_extra:     # tira restos finos das linhas da grade grudados na peça
        sub = ndi.binary_opening(sub, iterations=2 + open_extra)
    lab, n = ndi.label(sub)
    if n == 0:
        raise ValueError(f'{name} {box}: nada encontrado')
    sizes = ndi.sum(sub, lab, range(1, n + 1))
    if mode == 'largest':
        keep = lab == (1 + int(np.argmax(sizes)))
    else:
        keep = np.isin(lab, [k + 1 for k, s in enumerate(sizes) if s >= min_area])
    # buracos do tamanho de poucos pixels (ruído do JPEG) são preenchidos; áreas de fundo continuam vazias
    keep = keep | (ndi.binary_fill_holes(keep) & ~bgm_sub & ndi.binary_closing(keep, iterations=2))
    rgb = a[y0:y1, x0:x1].astype(float)
    alpha = ndi.binary_erosion(keep, iterations=1).astype(float)
    if despill:        # sombra rosada que o gerador pôs no pé de algumas peças
        r_, g_, b_ = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        alpha[(r_ > 1.8 * g_) & (r_ > b_) & (b_ > 1.1 * g_)] = 0
    if unmix is not None:
        rgb, alpha = unmix(rgb, alpha, a[y0:y1, x0:x1], bgm[y0:y1, x0:x1])
    alpha = ndi.gaussian_filter(alpha, 0.7)
    img = Image.fromarray(np.dstack([np.clip(rgb, 0, 255), alpha * 255]).astype(np.uint8), 'RGBA')
    bb = img.getchannel('A').point(lambda v: 255 if v > 24 else 0).getbbox()
    return img.crop(bb) if bb else img


def scale(img, s):
    return img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS)


def to_w(img, w):
    return scale(img, w / img.width)


def unmix_field(rgb, alpha, raw, bgm):
    """Campo de força translúcido: o rosa do fundo aparece através dele. Separa a cor do campo
    (ciano) da transparência, para o chão do jogo aparecer por trás."""
    bg = bg_of(raw).astype(float)
    field = np.array([150., 225., 255.])
    v = field - bg
    t = ((rgb - bg) @ v) / (v @ v)
    resid = np.linalg.norm(rgb - (bg + t[..., None] * v), axis=-1)
    near = resid < 40
    blend = near & (t > 0.04) & (t < 0.9)
    out_a = alpha.copy()
    out_a[blend] = np.clip(0.2 + t[blend] * 0.9, 0.2, 0.85)
    hole = ndi.binary_fill_holes(alpha > 0) & (alpha == 0) & near
    out_a[hole] = 0.15
    out = rgb.copy()
    out[blend | hole] = field
    out_a *= ndi.binary_opening(out_a > 0.1, iterations=4)   # restos finos das linhas da grade vistos pelo campo
    return out, out_a


def split_front(img, wall_frac, gray_only=False):
    """Divide uma fortaleza (vista em losango) em fundo e frente. A frente é a faixa dos muros da frente:
    em cada coluna, do pé do muro (o pixel visível mais baixo) até a altura do muro."""
    w, h = img.size
    a = np.asarray(img).copy()
    vis = a[..., 3] > 60
    if gray_only:      # pedra: ignora a terra espalhada na frente do portão ao achar o pé do muro
        rgb = a[..., :3].astype(float)
        sat = (rgb.max(-1) - rgb.min(-1)) / np.maximum(rgb.max(-1), 1)
        vis &= sat < 0.22
    bottom = np.array([np.nonzero(vis[:, x])[0].max() if vis[:, x].any() else h for x in range(w)], float)
    bottom = ndi.median_filter(bottom, size=25, mode='nearest')
    yy = np.mgrid[0:h, 0:w][0]
    front = yy >= bottom[None, :] - wall_frac * w
    fa, ba = a.copy(), a.copy()
    fa[~front, 3] = 0
    ba[front, 3] = 0
    return Image.fromarray(ba, 'RGBA'), Image.fromarray(fa, 'RGBA')


def robot_frames():
    """Robô minerador (npc_minerador.jpg, 6 × 4): andando de frente, de costas, de lado (direita) e cavando."""
    out = {}
    rows = {'front': (0, 470), 'back': (470, 930), 'side': (930, 1390)}
    xs = [0, 341, 682, 1024, 1365, 1706, 2048]
    for view, (y0, y1) in rows.items():
        for k in range(6):
            out[f'robo_{view}_{k}'] = pick('npc_minerador', (xs[k], y0, xs[k + 1], y1))
    for k, (x0, x1) in enumerate([(0, 520), (520, 1020), (1020, 1400), (1400, 1760)]):
        out[f'robo_dig_{k}'] = pick('npc_minerador', (x0, 1560, x1, 2048), mode='all', min_area=3000)
    s = 100 / max(im.height for n, im in out.items() if not n.startswith('robo_dig'))
    return {n: scale(im, s) for n, im in out.items()}


def build():
    S2 = {}
    # ---- Muros: 5 materiais (linhas) × peças (colunas). Mesma escala para todas as peças de um material.
    rows = {'madeira': (55, 440), 'pedra': (515, 870), 'tijolo': (945, 1340), 'ferro': (1410, 1690), 'fortaleza': (1730, 2040)}
    cols = {'h': (0, 345), 'v': (430, 600), 'portao': (1420, 1712), 'aberto': (1712, 2048)}
    for mat, (y0, y1) in rows.items():
        h = pick('b_muros', (cols['h'][0], y0, cols['h'][1], y1))
        s = 96 / h.width
        for part, (x0, x1) in cols.items():
            im = pick('b_muros', (x0, y0, x1, y1), mode='all' if part == 'aberto' else 'largest')
            S2[f'muro_{mat}_{part}'] = scale(im, s)
    # ---- Torres e armadilhas (mesma escala para todas)
    tcols = [(0, 345), (345, 684), (684, 1028), (1028, 1367), (1367, 1707), (1707, 2048)]
    tnames = ['torre_madeira', 'torre_pedra', 'torre_canhao', 'torre_balista', 'torre_balista_cristal', 'torre_cristal']
    for nm, (x0, x1) in zip(tnames, tcols):
        S2[nm] = scale(pick('b_torres', (x0, 0, x1, 520), despill=True), 0.43)
    for nm, box in {'cristal_roxo': (345, 560, 684, 1000), 'cristal_claro': (684, 560, 1028, 1000),
                    'espinhos': (1707, 560, 2048, 1000)}.items():
        S2[nm] = scale(pick('b_torres', box), 0.36)
    # ---- Casas: exterior (em cima à esquerda) e interior em corte (em cima à direita)
    for nm in ['cabana', 'pedra', 'castelo', 'saloon', 'tribal', 'domo']:
        S2[f'casa_{nm}'] = to_w(pick('b_' + nm, (0, 0, 1010, 790)), 340)
        S2[f'casa_{nm}_dentro'] = to_w(pick('b_' + nm, (1010, 0, 2048, 790)), 340)
    # ---- Móveis (todos na mesma escala, para ficarem proporcionais entre si)
    moveis = {
        'cama': ('b_cabana', (1050, 1120, 1365, 1410)), 'mesa': ('b_cabana', (1740, 1160, 2020, 1392)),
        'bau': ('b_cabana', (1100, 1705, 1310, 1910)), 'fogao': ('b_cabana', (1782, 1622, 1986, 1965)),
        'mesa_redonda': ('b_saloon', (410, 1725, 636, 1912)), 'banco': ('b_tribal', (730, 1714, 985, 1910)),
        'cesto': ('b_tribal', (1094, 1680, 1314, 1910)), 'fogueira': ('b_tribal', (1428, 1675, 1645, 1940)),
        'cama_casal': ('b_pedra', (92, 1642, 480, 1966)), 'bau_ferro': ('b_pedra', (1100, 1680, 1310, 1910)),
        'cofre': ('b_pedra', (1437, 1676, 1638, 1922)), 'cama_dossel': ('b_castelo', (92, 1564, 480, 1966)),
        'lareira': ('b_castelo', (1782, 1606, 1984, 1966)), 'capsula': ('b_domo', (54, 1646, 400, 1957)),
    }
    for nm, (sh, box) in moveis.items():
        S2['movel_' + nm] = scale(pick(sh, box), 0.34)
    # ---- Fortalezas: muralha com casas de camponeses ou vazia, forte do faroeste, colônia alienígena.
    # Nas muralhas de baixo a IA desenhou uma cama e um fogão encostados: apagados abaixo da linha do chão.
    def below(p, q, dy=0):
        (ax, ay), (bx, by) = p, q
        return lambda xx, yy: yy > ay + (by - ay) * (xx - ax) / (bx - ax) + dy
    # A muralha de baixo à direita veio com um fogão encostado na frente: apagado abaixo da linha do chão do muro.
    # A versão "com casas de camponeses" é montada no jogo (muralha vazia + cabanas dentro, que dá para mover).
    comps = {
        'muralha': pick('b_muralha', (1035, 1070, 2030, 1975), open_extra=2,
                        erase=lambda xx, yy: (xx > 1775) & (yy > 1812 - (xx - 1700) * 0.6)),
        'forte_cidade': pick('b_forte', (0, 0, 2048, 1012), open_extra=3),
        'forte': pick('b_forte', (0, 1012, 2048, 2048), open_extra=3),
        'colonia': pick('b_colonia', (0, 0, 2048, 1030), unmix=unmix_field, open_extra=3),
        'campo': pick('b_colonia', (0, 1030, 2048, 2048), unmix=unmix_field, open_extra=3),
    }
    wall = {'muralha': 0.21, 'forte_cidade': 0.068, 'forte': 0.068, 'colonia': 0.085, 'campo': 0.085}
    for nm, im in comps.items():
        im = to_w(im, 760)
        back, front = split_front(im, wall[nm], gray_only=nm == 'muralha')
        S2[f'forte_{nm}'] = to_w(im, 180)          # miniatura para a loja
        S2[f'forte_{nm}_fundo'] = back
        S2[f'forte_{nm}_frente'] = front
    return S2


def pack_and_write(S2):
    names = sorted(S2, key=lambda n: -S2[n].height)
    AW, pad = 2048, 2
    x = y = shelf = 0
    pos = {}
    for n in names:
        im = S2[n]
        if x + im.width + pad > AW:
            x = 0; y += shelf + pad; shelf = 0
        pos[n] = [x, y, im.width, im.height]
        x += im.width + pad; shelf = max(shelf, im.height)
    AH = y + shelf
    atlas = Image.new('RGBA', (AW, AH), (0, 0, 0, 0))
    for n, (px, py, w, h) in pos.items():
        atlas.paste(S2[n], (px, py), S2[n])
    atlas.save(os.path.join(ROOT, 'assets', 'estruturas.webp'), quality=88, method=6)
    atlas.save(os.path.join(ROOT, 'tools', 'estruturas-preview.png'))
    gp = os.path.join(ROOT, 'game.js')
    g = open(gp, encoding='utf-8').read()
    g = re.sub(r'/\*ATLAS2_MAP\*/.*?/\*FIM_ATLAS2\*/', '/*ATLAS2_MAP*/' + json.dumps(pos, separators=(',', ':')) + '/*FIM_ATLAS2*/', g, flags=re.S)
    open(gp, 'w', encoding='utf-8').write(g)
    print('estruturas', AW, AH, len(pos), 'sprites')


if __name__ == '__main__':
    pack_and_write(build())
