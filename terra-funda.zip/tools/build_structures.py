"""Construções: muros, portões, torres, casas, fortalezas e móveis (folhas b_*.jpg em tools/sprites-src).
Chamado pelo build_atlas.py. Gera assets/estruturas.webp e o mapa ATLAS2 dentro do game.js.
As folhas novas têm fundo rosa ou magenta e linhas de grade escuras; aqui as linhas são apagadas
e cada peça é recortada pelos componentes conectados dentro de uma caixa (coordenadas da folha 2048 × 2048)."""
import os, json, re
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'tools', 'sprites-src')


def bg_of(a):
    q = (a[::7, ::7] // 8 * 8).reshape(-1, 3)
    u, c = np.unique(q, axis=0, return_counts=True)
    return u[c.argmax()].astype(int) + 4


def fg_mask(a):
    """Tudo que não é fundo, sem as linhas da grade (escuras, finas e com fundo dos dois lados)."""
    r, g, b = [a[..., k].astype(int) for k in range(3)]
    d = np.sqrt(((a.astype(int) - bg_of(a)) ** 2).sum(-1))
    bgm = ((r > 90) & (b > 90) & (g < 0.6 * np.minimum(r, b))) | (d < 48)
    lum = a.mean(-1)
    dark = (lum < 120) & ~bgm
    line = np.zeros_like(bgm)
    for ax in (0, 1):
        frac = dark.mean(axis=1 - ax)
        n = len(frac)
        for i in range(n):
            nb = min(frac[max(0, i - 9)], frac[min(n - 1, i + 9)])
            if frac[i] > 0.2 and frac[i] - nb > 0.15:
                for j in range(max(0, i - 4), min(n, i + 5)):
                    if ax == 0:
                        side = np.roll(bgm, 9, 0)[j] | np.roll(bgm, -9, 0)[j]
                        line[j] |= dark[j] & side
                    else:
                        side = np.roll(bgm, 9, 1)[:, j] | np.roll(bgm, -9, 1)[:, j]
                        line[:, j] |= dark[:, j] & side
    return ndi.binary_opening(~bgm & ~line, iterations=2), bgm


_cache = {}
def sheet(name):
    if name not in _cache:
        a = np.asarray(Image.open(os.path.join(SRC, name + '.jpg')).convert('RGB'))
        fg, bgm = fg_mask(a)
        _cache[name] = (a, fg, bgm)
    return _cache[name]


def pick(name, box, mode='largest', min_area=900, erase=None, unmix=None, open_extra=0, despill=False, crop=True):
    """Recorta a peça dentro de box = (x0, y0, x1, y1). mode 'largest' fica com o maior pedaço,
    'all' junta todos os pedaços grandes. erase(xx, yy) -> máscara de pixels a apagar (coords da folha)."""
    a, fg, bgm = sheet(name)
    x0, y0, x1, y1 = box
    sub = fg[y0:y1, x0:x1].copy()
    bgm_sub = bgm[y0:y1, x0:x1]
    if erase is not None:
        yy, xx = np.mgrid[y0:y1, x0:x1]
        sub &= ~erase(xx, yy)
        sub = ndi.binary_opening(sub, iterations=2)
    if open_extra:     # tira restos finos das linhas da grade grudados na peça
        sub = ndi.binary_opening(sub, iterations=2 + open_extra)
    lab, n = ndi.label(sub)
    if n == 0:
        raise ValueError(f'{name} {box}: nada encontrado')
    sizes = ndi.sum(sub, lab, range(1, n + 1))
    if mode == 'largest':
        keep = lab == (1 + int(np.argmax(sizes)))
    else:
        keep = np.isin(lab, [k + 1 for k, s in enumerate(sizes) if s >= min_area])
    # buracos do tamanho de poucos pixels (ruído do JPEG) são preenchidos; áreas de fundo continuam vazias
    keep = keep | (ndi.binary_fill_holes(keep) & ~bgm_sub & ndi.binary_closing(keep, iterations=2))
    rgb = a[y0:y1, x0:x1].astype(float)
    alpha = ndi.binary_erosion(keep, iterations=1).astype(float)
    if despill:        # sombra rosada que o gerador pôs no pé de algumas peças
        r_, g_, b_ = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        alpha[(r_ > 1.8 * g_) & (r_ > b_) & (b_ > 1.1 * g_)] = 0
    if unmix is not None:
        rgb, alpha = unmix(rgb, alpha, a[y0:y1, x0:x1], bgm[y0:y1, x0:x1])
    alpha = ndi.gaussian_filter(alpha, 0.7)
    img = Image.fromarray(np.dstack([np.clip(rgb, 0, 255), alpha * 255]).astype(np.uint8), 'RGBA')
    bb = img.getchannel('A').point(lambda v: 255 if v > 24 else 0).getbbox()
    return img.crop(bb) if bb and crop else img


def scale(img, s):
    return img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS)


def to_w(img, w):
    return scale(img, w / img.width)


def unmix_field(rgb, alpha, raw, bgm):
    """Campo de força translúcido: o rosa do fundo aparece através dele. Separa a cor do campo
    (ciano) da transparência, para o chão do jogo aparecer por trás."""
    bg = bg_of(raw).astype(float)
    field = np.array([150., 225., 255.])
    v = field - bg
    t = ((rgb - bg) @ v) / (v @ v)
    resid = np.linalg.norm(rgb - (bg + t[..., None] * v), axis=-1)
    near = resid < 40
    blend = near & (t > 0.04) & (t < 0.9)
    out_a = alpha.copy()
    out_a[blend] = np.clip(0.2 + t[blend] * 0.9, 0.2, 0.85)
    hole = ndi.binary_fill_holes(alpha > 0) & (alpha == 0) & near
    out_a[hole] = 0.15
    out = rgb.copy()
    out[blend | hole] = field
    out_a *= ndi.binary_opening(out_a > 0.1, iterations=4)   # restos finos das linhas da grade vistos pelo campo
    return out, out_a


def split_front(img, wall_frac, gray_only=False):
    """Divide uma fortaleza (vista em losango) em fundo e frente. A frente é a faixa dos muros da frente:
    em cada coluna, do pé do muro (o pixel visível mais baixo) até a altura do muro."""
    w, h = img.size
    a = np.asarray(img).copy()
    vis = a[..., 3] > 60
    if gray_only:      # pedra: ignora a terra espalhada na frente do portão ao achar o pé do muro
        rgb = a[..., :3].astype(float)
        sat = (rgb.max(-1) - rgb.min(-1)) / np.maximum(rgb.max(-1), 1)
        vis &= sat < 0.22
    bottom = np.array([np.nonzero(vis[:, x])[0].max() if vis[:, x].any() else h for x in range(w)], float)
    bottom = ndi.median_filter(bottom, size=25, mode='nearest')
    yy = np.mgrid[0:h, 0:w][0]
    front = yy >= bottom[None, :] - wall_frac * w
    # chão: terra abaixo do pé do muro (fica embaixo de quem anda por cima, não na camada do muro)
    rgb = a[..., :3].astype(float)
    sat = (rgb.max(-1) - rgb.min(-1)) / np.maximum(rgb.max(-1), 1)
    ground = front & (yy > bottom[None, :] + 3) & (sat >= 0.18) if gray_only else np.zeros_like(front)
    fa, ba, ga = a.copy(), a.copy(), a.copy()
    fa[~front | ground, 3] = 0
    ba[front, 3] = 0
    ga[~ground, 3] = 0
    return Image.fromarray(ba, 'RGBA'), Image.fromarray(fa, 'RGBA'), Image.fromarray(ga, 'RGBA')


def split_carpet(img, tiles_w=8, tiles_h=4, pad=0.15, margin=0.02):
    """Casa vista em losango: o que fica abaixo das duas paredes da frente (a terra em volta da porta)
    vira tapete no chão, desenhado embaixo de quem passa por cima."""
    w, h = img.size
    a = np.asarray(img).copy()
    s = w / tiles_w
    yb = h - pad * s
    xx = np.mgrid[0:h, 0:w][1]; yy = np.mgrid[0:h, 0:w][0]
    edge = yb - (tiles_h / 2) * s * np.abs(xx - w / 2) / (w / 2)
    ground = yy > edge + margin * s
    ba, ga = a.copy(), a.copy()
    ba[ground, 3] = 0
    ga[~ground, 3] = 0
    return Image.fromarray(ba, 'RGBA'), Image.fromarray(ga, 'RGBA')


def soft_pick(name, box, min_area=600, reach=30, glow=(238, 222, 255)):
    """Recorte para peças com brilho (magia): o roxo fica sólido e o halo rosado vira transparência,
    em vez de ser apagado junto com o fundo magenta."""
    a = np.asarray(Image.open(os.path.join(SRC, name + '.jpg')).convert('RGB')).astype(float)
    x0, y0, x1, y1 = box
    a = a[y0:y1, x0:x1]
    bg = bg_of(a.astype(np.uint8)).astype(float)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    d = np.sqrt(((a - bg) ** 2).sum(-1))
    mag = (r > 170) & (b > 170) & (g < np.minimum(r, b) - 35)
    alpha = np.where(mag, np.clip((d - 35) / 190, 0, 1), 1.0)
    alpha[d < 45] = 0
    solid = alpha > 0.6
    lab, n = ndi.label(solid)
    if n:
        sizes = ndi.sum(solid, lab, range(1, n + 1))
        keep = np.isin(lab, [k + 1 for k, v in enumerate(sizes) if v >= min_area])
        alpha *= ndi.binary_dilation(keep, iterations=reach)
    col = np.where(mag[..., None], np.array(glow, float), a)   # o halo vira a cor do brilho, sem tom rosado
    img = Image.fromarray(np.dstack([np.clip(col, 0, 255), alpha * 255]).astype(np.uint8), 'RGBA')
    bb = img.getchannel('A').point(lambda v: 255 if v > 20 else 0).getbbox()
    return img.crop(bb) if bb else img


def fit_box(img, n):
    k = n / max(img.width, img.height)
    return scale(img, k)


def weapon_frames():
    """Arco, flechas e cetro mágico (armas.jpg): ícones e os efeitos dos disparos."""
    W = 'armas'
    out = {
        'icon_arco': fit_box(pick(W, (60, 60, 700, 700)), 56),
        'icon_flechas': fit_box(pick(W, (740, 60, 1330, 700)), 56),
        'icon_cetro': fit_box(soft_pick(W, (60, 760, 640, 1330)), 56),
        'arco_mao': fit_box(pick(W, (60, 60, 700, 700)), 96),
        'cetro_mao': fit_box(soft_pick(W, (60, 760, 640, 1330)), 110),
        'cetro_brilho': fit_box(soft_pick(W, (680, 700, 1330, 1330), reach=45), 110),
        'flecha_voo': fit_box(pick(W, (1650, 250, 2350, 470)), 64),
        'magia_voo': fit_box(soft_pick(W, (1380, 860, 1800, 1160), min_area=300, reach=60), 56),
        'magia_estouro': fit_box(soft_pick(W, (1950, 780, 2450, 1290), min_area=200, reach=40), 72),
    }
    return out


def grid_cell(name, cols, rows, c, r, inset=10):
    im = Image.open(os.path.join(SRC, name + '.jpg'))
    cw, ch = im.width / cols, im.height / rows
    return (int(c * cw) + inset, int(r * ch) + inset, int((c + 1) * cw) - inset, int((r + 1) * ch) - inset)


def mob_frames():
    """Saqueador, chefe do bando (6 × 4) e bicho do petróleo (6 × 5)."""
    out = {}
    def biped(sheet, pre, back_cells, side_cells, px):
        fr = {}
        cell = lambda c, r: grid_cell(sheet, 6, 4, c, r)
        for c in range(6): fr[f'{pre}_front_{c}'] = pick(sheet, cell(c, 0))
        for k, (c, r) in enumerate(back_cells): fr[f'{pre}_back_{k}'] = pick(sheet, cell(c, r))
        for k, (c, r) in enumerate(side_cells): fr[f'{pre}_side_{k}'] = pick(sheet, cell(c, r))
        fr[f'{pre}_atk_front_0'] = pick(sheet, cell(0, 3)); fr[f'{pre}_atk_front_1'] = pick(sheet, cell(1, 3))
        fr[f'{pre}_atk_side_0'] = pick(sheet, cell(2, 3)); fr[f'{pre}_atk_side_1'] = pick(sheet, cell(3, 3))
        fr[f'{pre}_hit'] = pick(sheet, cell(4, 3), mode='all', min_area=2000)
        fr[f'{pre}_dead'] = pick(sheet, cell(5, 3), mode='all', min_area=2000)
        ref = max(im.height for n, im in fr.items() if '_front_' in n)
        return {n: scale(im, px / ref) for n, im in fr.items()}
    out.update(biped('mob_saqueador', 'saq', [(c, 1) for c in range(6)], [(c, 2) for c in range(6)], 100))
    out.update(biped('mob_chefe', 'chefe', [(0, 1), (1, 1), (2, 1)], [(0, 2), (1, 2), (2, 2), (3, 2), (5, 2)], 112))
    B = 'mob_bicho'
    cell = lambda c, r: grid_cell(B, 6, 5, c, r)
    fr = {}
    for c in range(4): fr[f'bicho_front_{c}'] = pick(B, cell(c, 0))
    for c in range(5): fr[f'bicho_back_{c}'] = pick(B, cell(c, 1))
    for c in range(5): fr[f'bicho_side_{c}'] = pick(B, cell(c, 2))
    for c in range(4): fr[f'bicho_dig_{c}'] = pick(B, cell(c, 3), mode='all', min_area=1500)
    fr['bicho_atk'] = pick(B, cell(4, 3), mode='all', min_area=1500)
    im = Image.open(os.path.join(SRC, B + '.jpg'))
    fr['bicho_dead'] = pick(B, (int(im.width * 4 / 6), int(im.height * 4 / 5) + 10, im.width - 10, im.height - 10), mode='all', min_area=1500)
    k = 74 / max(v.height for n, v in fr.items() if n.startswith('bicho_side'))
    dead = fr.pop('bicho_dead')
    out.update({n: scale(v, k) for n, v in fr.items()})
    out['bicho_dead'] = to_w(dead, int(out['bicho_side_0'].width * 1.35))
    # livro de cura, fumaças e anéis
    L = 'livro'
    out['icon_livro'] = fit_box(pick(L, (130, 110, 540, 540)), 56)
    out['livro_mao'] = fit_box(soft_pick(L, (700, 140, 1240, 520)), 64)
    out['livro_brilho'] = fit_box(soft_pick(L, (1330, 20, 1860, 520), glow=(255, 200, 120)), 64)
    for cor, x0 in (('verde', 170), ('vermelha', 800), ('dourada', 2080)):
        out['fumaca_' + cor] = fit_box(pick(L, (x0, 640, x0 + 330, 980), mode='all', min_area=400), 40)
    # a roxa some junto com o fundo magenta: sai da verde com outra cor
    g = np.asarray(out['fumaca_verde']).astype(float)
    lum = g[..., :3].mean(-1, keepdims=True) / 160
    roxa = np.concatenate([np.clip(lum * np.array([176, 108, 230]), 0, 255), g[..., 3:]], -1)
    out['fumaca_roxa'] = Image.fromarray(roxa.astype(np.uint8), 'RGBA')
    out['anel_cura'] = fit_box(soft_pick(L, (60, 1000, 600, 1370), min_area=300, reach=20, glow=(150, 255, 160)), 160)
    out['anel_explosao'] = fit_box(soft_pick(L, (1980, 1000, 2520, 1370), min_area=300, reach=20, glow=(220, 140, 255)), 160)
    return out


def fx_frames():
    """Efeitos de combate (efeitos.jpg, 6 × 4): cortes, faíscas, rastros, explosões, fogo e tontura."""
    E = 'efeitos'
    names = [['corte_0', 'corte_1', 'corte_2', 'corte_laranja', 'corte_roxo', 'corte_dourado'],
             ['faisca_0', 'faisca_1', 'faisca_2', 'lascas', 'poeira', 'estrela'],
             ['rastro_flecha', 'rastro_fogo', 'rastro_magia', 'magia_hit_0', 'magia_hit_1', 'magia_hit_2'],
             ['fogo_0', 'fogo_1', 'fogo_2', 'tontura_0', 'tontura_1', 'impacto']]
    solid = {'lascas', 'poeira', 'estrela', 'fogo_0', 'fogo_1', 'tontura_0', 'tontura_1', 'impacto', 'corte_laranja', 'corte_dourado', 'rastro_fogo'}
    out = {}
    for r, row in enumerate(names):
        for c, nm in enumerate(row):
            box = grid_cell(E, 6, 4, c, r, inset=12)
            im = pick(E, box, mode='all', min_area=40) if nm in solid else soft_pick(E, box, min_area=40, reach=25, glow=(255, 240, 255) if r < 2 else (220, 170, 255))
            out['fx_' + nm] = im
    # quadros de uma mesma animação na mesma escala (o primeiro é pequeno de propósito)
    for grp in (['corte_0', 'corte_1', 'corte_2'], ['faisca_0', 'faisca_1', 'faisca_2'], ['magia_hit_0', 'magia_hit_1'], ['fogo_0', 'fogo_1', 'fogo_2']):
        k = 72 / max(max(out['fx_' + g].size) for g in grp)
        for g in grp: out['fx_' + g] = scale(out['fx_' + g], k)
    for n in list(out):
        if max(out[n].size) > 80: out[n] = fit_box(out[n], 72)
    # o último quadro da explosão de magia veio quase invisível: usa o do meio maior
    out['fx_magia_hit_2'] = scale(out['fx_magia_hit_1'], 1.25)
    return out


def farmer_frames():
    """Ajudante de fazenda (npc_ajudante.jpg, 6 × 4). Na linha 1 só as 4 primeiras são de frente."""
    A = 'npc_ajudante'
    cell = lambda c, r: grid_cell(A, 6, 4, c, r)
    out = {}
    for c in range(4): out[f'faz_front_{c}'] = pick(A, cell(c, 0))
    for c in range(6): out[f'faz_back_{c}'] = pick(A, cell(c, 1))
    for c in range(6): out[f'faz_side_{c}'] = pick(A, cell(c, 2))
    for c, nm in enumerate(['colher_0', 'colher_1', 'plantar_0', 'plantar_1', 'feliz', 'sentado']):
        out['faz_' + nm] = pick(A, cell(c, 3), mode='all', min_area=1500)
    k = 100 / max(v.height for n, v in out.items() if n.startswith('faz_front'))
    return {n: scale(v, k) for n, v in out.items()}


def robot_frames():
    """Robô minerador (npc_minerador.jpg, 6 × 4): andando de frente, de costas, de lado (direita) e cavando."""
    out = {}
    rows = {'front': (0, 470), 'back': (470, 930), 'side': (930, 1390)}
    xs = [0, 341, 682, 1024, 1365, 1706, 2048]
    for view, (y0, y1) in rows.items():
        for k in range(6):
            out[f'robo_{view}_{k}'] = pick('npc_minerador', (xs[k], y0, xs[k + 1], y1))
    for k, (x0, x1) in enumerate([(0, 520), (520, 1020), (1020, 1400), (1400, 1760)]):
        out[f'robo_dig_{k}'] = pick('npc_minerador', (x0, 1560, x1, 2048), mode='all', min_area=3000)
    s = 100 / max(im.height for n, im in out.items() if not n.startswith('robo_dig'))
    return {n: scale(im, s) for n, im in out.items()}


def build():
    S2 = {}
    # ---- Catapultas (b_catapulta.jpg): 4 quadros do disparo, pedra voando, impacto, pilha e a reforçada
    C = 'b_catapulta'
    # os 4 quadros recortados com caixas do mesmo tamanho e cortados juntos, para não "pular" na animação
    cat = [pick(C, (x, 70, x + 600, 620), mode='all', min_area=3000, crop=False) for x in (60, 680, 1300, 1920)]
    box = cat[0].getbbox()
    for im in cat[1:]:
        b2 = im.getbbox(); box = (min(box[0], b2[0]), min(box[1], b2[1]), max(box[2], b2[2]), max(box[3], b2[3]))
    cat = [im.crop(box) for im in cat]
    k = 150 / cat[0].width
    for j, im in enumerate(cat):
        S2[f'catapulta_{j}'] = scale(im, k)
    S2['catapulta_ferro'] = scale(pick(C, (1800, 800, 2480, 1300)), k)
    S2['catapulta_pedra'] = scale(pick(C, (400, 780, 600, 940)), k)
    S2['catapulta_impacto'] = scale(soft_pick(C, (800, 900, 1220, 1230), min_area=400, reach=50, glow=(196, 168, 134)), k)
    S2['catapulta_pilha'] = scale(pick(C, (1400, 990, 1680, 1200)), k)
    # ---- Móveis do cômodo (moveis_iso.jpg, 6 × 4), todos na mesma escala (ISO_K no game.js)
    nomes = [['cama', 'cama_casal', 'cama_dossel', 'criado', 'guarda_roupa', 'espelho'],
             ['sofa', 'poltrona', 'mesinha', 'estante', 'lareira', 'tapete'],
             ['mesa', 'cadeira', 'pia', 'fogao', 'geladeira', 'barril'],
             ['planta', 'luminaria', 'quadro', 'bau', 'cofre', 'aquario']]
    for r, row in enumerate(nomes):
        for c, nm in enumerate(row):
            box = grid_cell('moveis_iso', 6, 4, c, r, inset=8)
            im = soft_pick('moveis_iso', box, min_area=40, reach=60, glow=(200, 160, 90)) if nm == 'luminaria' else pick('moveis_iso', box, mode='all', min_area=600)
            S2['iso_' + nm] = scale(im, 0.4)   # haste fina da luminária: recorte que não apaga linhas finas
    # ---- Muros: 5 materiais (linhas) × peças (colunas). Mesma escala para todas as peças de um material.
    rows = {'madeira': (55, 440), 'pedra': (515, 870), 'tijolo': (945, 1340), 'ferro': (1410, 1690), 'fortaleza': (1730, 2040)}
    cols = {'h': (0, 345), 'v': (430, 600), 'portao': (1420, 1712), 'aberto': (1712, 2048)}
    for mat, (y0, y1) in rows.items():
        h = pick('b_muros', (cols['h'][0], y0, cols['h'][1], y1))
        s = 96 / h.width
        for part, (x0, x1) in cols.items():
            im = pick('b_muros', (x0, y0, x1, y1), mode='all' if part == 'aberto' else 'largest')
            S2[f'muro_{mat}_{part}'] = scale(im, s)
    # ---- Torres e armadilhas (mesma escala para todas)
    tcols = [(0, 345), (345, 684), (684, 1028), (1028, 1367), (1367, 1707), (1707, 2048)]
    tnames = ['torre_madeira', 'torre_pedra', 'torre_canhao', 'torre_balista', 'torre_balista_cristal', 'torre_cristal']
    for nm, (x0, x1) in zip(tnames, tcols):
        S2[nm] = scale(pick('b_torres', (x0, 0, x1, 520), despill=True), 0.43)
    for nm, box in {'cristal_roxo': (345, 560, 684, 1000), 'cristal_claro': (684, 560, 1028, 1000),
                    'espinhos': (1707, 560, 2048, 1000)}.items():
        S2[nm] = scale(pick('b_torres', box), 0.36)
    # ---- Casas: exterior (em cima à esquerda) e interior em corte (em cima à direita)
    for nm in ['cabana', 'pedra', 'castelo', 'saloon', 'tribal', 'domo']:
        for suf, box in (('', (0, 0, 1010, 790)), ('_dentro', (1010, 0, 2048, 790))):
            body, carpet = split_carpet(to_w(pick('b_' + nm, box), 340))
            S2[f'casa_{nm}{suf}'] = body
            if carpet.getbbox(): S2[f'casa_{nm}{suf}_chao'] = carpet
    # ---- Móveis (todos na mesma escala, para ficarem proporcionais entre si)
    moveis = {
        'cama': ('b_cabana', (1050, 1120, 1365, 1410)), 'mesa': ('b_cabana', (1740, 1160, 2020, 1392)),
        'bau': ('b_cabana', (1100, 1705, 1310, 1910)), 'fogao': ('b_cabana', (1782, 1622, 1986, 1965)),
        'mesa_redonda': ('b_saloon', (410, 1725, 636, 1912)), 'banco': ('b_tribal', (730, 1714, 985, 1910)),
        'cesto': ('b_tribal', (1094, 1680, 1314, 1910)), 'fogueira': ('b_tribal', (1428, 1675, 1645, 1940)),
        'cama_casal': ('b_pedra', (92, 1642, 480, 1966)), 'bau_ferro': ('b_pedra', (1100, 1680, 1310, 1910)),
        'cofre': ('b_pedra', (1437, 1676, 1638, 1922)), 'cama_dossel': ('b_castelo', (92, 1564, 480, 1966)),
        'lareira': ('b_castelo', (1782, 1606, 1984, 1966)), 'capsula': ('b_domo', (54, 1646, 400, 1957)),
    }
    for nm, (sh, box) in moveis.items():
        S2['movel_' + nm] = scale(pick(sh, box), 0.34)
    # ---- Fortalezas: muralha com casas de camponeses ou vazia, forte do faroeste, colônia alienígena.
    # Nas muralhas de baixo a IA desenhou uma cama e um fogão encostados: apagados abaixo da linha do chão.
    def below(p, q, dy=0):
        (ax, ay), (bx, by) = p, q
        return lambda xx, yy: yy > ay + (by - ay) * (xx - ax) / (bx - ax) + dy
    # A muralha de baixo à direita veio com um fogão encostado na frente: apagado abaixo da linha do chão do muro.
    # A versão "com casas de camponeses" é montada no jogo (muralha vazia + cabanas dentro, que dá para mover).
    comps = {
        'muralha': pick('b_muralha', (1035, 1070, 2030, 1975), open_extra=2,
                        erase=lambda xx, yy: (xx > 1775) & (yy > 1812 - (xx - 1700) * 0.6)),
        'forte_cidade': pick('b_forte', (0, 0, 2048, 1012), open_extra=3),
        'forte': pick('b_forte', (0, 1012, 2048, 2048), open_extra=3),
        'colonia': pick('b_colonia', (0, 0, 2048, 1030), unmix=unmix_field, open_extra=3),
        'campo': pick('b_colonia', (0, 1030, 2048, 2048), unmix=unmix_field, open_extra=3),
    }
    wall = {'muralha': 0.21, 'forte_cidade': 0.068, 'forte': 0.068, 'colonia': 0.085, 'campo': 0.085}
    for nm, im in comps.items():
        im = to_w(im, 760)
        back, front, ground = split_front(im, wall[nm], gray_only=nm == 'muralha')
        if ground.getbbox(): S2[f'forte_{nm}_chao'] = ground
        S2[f'forte_{nm}'] = to_w(im, 180)          # miniatura para a loja
        S2[f'forte_{nm}_fundo'] = back
        S2[f'forte_{nm}_frente'] = front
    return S2


def pack_and_write(S2):
    names = sorted(S2, key=lambda n: -S2[n].height)
    AW, pad = 2048, 2
    x = y = shelf = 0
    pos = {}
    for n in names:
        im = S2[n]
        if x + im.width + pad > AW:
            x = 0; y += shelf + pad; shelf = 0
        pos[n] = [x, y, im.width, im.height]
        x += im.width + pad; shelf = max(shelf, im.height)
    AH = y + shelf
    atlas = Image.new('RGBA', (AW, AH), (0, 0, 0, 0))
    for n, (px, py, w, h) in pos.items():
        atlas.paste(S2[n], (px, py), S2[n])
    atlas.save(os.path.join(ROOT, 'assets', 'estruturas.webp'), quality=88, method=6)
    atlas.save(os.path.join(ROOT, 'tools', 'estruturas-preview.png'))
    gp = os.path.join(ROOT, 'game.js')
    g = open(gp, encoding='utf-8').read()
    g = re.sub(r'/\*ATLAS2_MAP\*/.*?/\*FIM_ATLAS2\*/', '/*ATLAS2_MAP*/' + json.dumps(pos, separators=(',', ':')) + '/*FIM_ATLAS2*/', g, flags=re.S)
    open(gp, 'w', encoding='utf-8').write(g)
    print('estruturas', AW, AH, len(pos), 'sprites')


if __name__ == '__main__':
    pack_and_write(build())
