"""Recorta as folhas de sprites (fundo magenta), limpa o fundo e monta o atlas do jogo.
Uso: python3 tools/build_atlas.py  (precisa de Pillow, numpy e scipy). As folhas ficam em tools/sprites-src.
Gera atlas.png + atlas.json (nome -> [x, y, w, h]) e uma folha de conferência."""
import json, numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi

import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'tools', 'sprites-src', 'img%d.jpg')
IM = {i: Image.open(SRC % i).convert('RGB') for i in (3, 4, 5, 7, 8)}

def key_mask(a):
    r, g, b = [a[..., k].astype(int) for k in range(3)]
    return (r > 90) & (b > 90) & (g < 0.6 * np.minimum(r, b))

def cut(i, box, keep_largest=False):
    """box = (x0, y0, x1, y1) em pixels da imagem original. Remove o magenta e aperta a caixa."""
    a = np.asarray(IM[i].crop(box))
    fg = ~key_mask(a)
    fg = ndi.binary_opening(fg, iterations=2)
    if keep_largest:
        lab, n = ndi.label(fg)
        if n > 1:
            sizes = ndi.sum(fg, lab, range(1, n + 1))
            fg = lab == (1 + int(np.argmax(sizes)))
    fg = ndi.binary_erosion(fg, iterations=2)          # tira a franja rosa do JPEG
    alpha = ndi.gaussian_filter(fg.astype(float), 0.8)
    rgba = np.dstack([a, (alpha * 255).astype(np.uint8)])
    img = Image.fromarray(rgba, 'RGBA')
    bb = img.getbbox()
    return img.crop(bb) if bb else img

def plain(i, box):
    return IM[i].crop(box).convert('RGBA')

def fit(img, w, h):
    s = min(w / img.width, h / img.height)
    return img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS)

def seamless(img):
    a = np.asarray(img.convert('RGB')).astype(float)
    n, m = a.shape[:2]
    rolled = np.roll(a, (n // 2, m // 2), (0, 1))
    yy, xx = np.mgrid[0:n, 0:m]
    d = np.minimum.reduce([xx, m - 1 - xx, yy, n - 1 - yy]) / (min(n, m) / 2)
    w = np.clip(d * 1.6, 0, 1)
    w = (w * w * (3 - 2 * w))[..., None]
    out = a * w + rolled * (1 - w)
    return Image.fromarray(out.astype(np.uint8)).convert('RGBA')

def tile(i, x, y, size, out=64):
    return seamless(plain(i, (x, y, x + size, y + size))).resize((out, out), Image.LANCZOS)

def cube_top(i, box, out=64):
    """Os blocos do subsolo vieram como cubos isométricos: pega a face de cima e endireita num quadrado."""
    a = np.asarray(IM[i].crop(box))
    fg = ndi.binary_opening(~key_mask(a), iterations=2)
    ys, xs = np.nonzero(fg)
    ty = ys.min(); cx = int(np.median(xs[ys <= ty + 3]))
    lx = xs.min(); ly = int(ys[xs <= lx + 2].min())
    rx = xs.max(); ry = int(ys[xs >= rx - 2].min())
    my = (ly + ry) / 2
    by = my + (my - ty)
    inset = 0.08
    def lerp(p, q, t): return (p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t)
    c = (cx, (ty + by) / 2)
    T_, L_, B_, R_ = [lerp(p, c, inset) for p in [(cx, ty), (lx, ly), (cx, by), (rx, ry)]]
    src = Image.fromarray(a)
    # QUAD: canto superior-esquerdo, inferior-esquerdo, inferior-direito, superior-direito do destino
    quad = (T_[0], T_[1], L_[0], L_[1], B_[0], B_[1], R_[0], R_[1])
    return src.transform((out, out), Image.QUAD, quad, Image.BICUBIC).convert('RGBA')

S = {}
IMG_IDS = {}
BIOMES = ['campos', 'floresta', 'pantano', 'deserto', 'montanhas', 'neve']

# ---- Terreno dos biomas (imagem 3): faixa de chão, árvore, pedra
rows_c = [142, 365, 594, 816, 1039, 1259]
grid = [0, 252, 477, 699, 922, 1144, 1363]
rocks = [(1690, 75, 1866, 203), (1690, 294, 1864, 445), (1684, 533, 1875, 657),
         (1685, 735, 1870, 893), (1669, 923, 1890, 1138), (1661, 1172, 1897, 1348)]
for k, b in enumerate(BIOMES):
    for v, x in enumerate([70, 270, 470, 680]):
        S[f'ground_{b}_{v}'] = tile(3, x, rows_c[k] - 78, 156)
    S[f'tree_{b}'] = fit(cut(3, (1175, grid[k] + 2, 1405, grid[k + 1] - 2), keep_largest=True), 80, 104)
    S[f'rock_{b}'] = fit(cut(3, rocks[k]), 60, 56)

# ---- Fazenda (imagem 4)
for v, (x, y) in enumerate([(70, 140), (250, 140), (70, 330), (250, 330)]):
    S[f'tilled_{v}'] = tile(4, x, y, 200)
for f, x in enumerate([940, 1200, 1460]):
    S[f'water_{f}'] = tile(4, x, 150, 150)
S['spring'] = fit(cut(4, (1684, 114, 1971, 339)), 64, 64)
S['hole'] = fit(cut(4, (1981, 107, 2274, 345)), 64, 64)
S['wall'] = fit(cut(4, (2291, 102, 2562, 436)), 64, 76)
wheat = [(4, 893, 327, 1091), (340, 838, 665, 1090), (680, 762, 1096, 1140), (1097, 778, 1430, 1114)]
for k, b in enumerate(wheat):
    S[f'wheat_{k}'] = fit(cut(4, b, keep_largest=True), 64, 80)

# ---- Subsolo (imagem 5): face de cima dos cubos
cubes = {'dirt': (900, 72, 1158, 360), 'stone': (1418, 73, 1676, 359),
         'coal': (82, 429, 399, 780), 'bronze': (570, 429, 885, 781), 'iron': (1119, 429, 1434, 780),
         'silver': (1635, 429, 1952, 781), 'gold': (1971, 429, 2285, 780),
         'oil': (58, 865, 396, 1237), 'diamond': (547, 865, 884, 1238)}
for k, b in cubes.items():
    S[k] = cube_top(5, b)
for v, (x, y) in enumerate([(250, 190), (330, 230), (410, 190), (290, 250)]):
    t = tile(5, x, y, 150)
    a = np.asarray(t).astype(float)
    a[..., :3] = a[..., :3] * [0.62, 0.55, 0.5]          # túnel mais escuro e quente que a pedra
    S[f'floor_{v}'] = Image.fromarray(a.astype(np.uint8), 'RGBA')


# ---- Passada de lado. As folhas só trazem poses de pernas abertas; daqui saem a pose parada
# (pernas juntas) e o ciclo completo: aberta → meio → juntas → meio, alternando duas passadas.
def close_legs(img, k, hip=0.6):
    """Aproxima os pés do centro (k=1 passada aberta, k=0 pernas juntas), girando cada perna a partir do quadril."""
    a = np.asarray(img).copy(); h, w = a.shape[:2]; y0 = int(h * hip)
    al = a[..., 3] > 40
    xs = np.nonzero(al[max(0, y0 - 6):y0].any(0))[0]
    cx = (xs.min() + xs.max()) / 2 if len(xs) else w / 2
    fy = int(h * 0.9)
    fx = np.nonzero(al[fy:].any(0))[0]
    if not len(fx): return img
    lf = fx[fx < cx]; rf = fx[fx >= cx]
    dl = (cx - lf.mean()) if len(lf) else 0
    dr = (rf.mean() - cx) if len(rf) else 0
    out = a.copy(); out[y0:] = 0
    left = np.zeros_like(a); right = np.zeros_like(a)
    for y in range(y0, h):
        t = (y - y0) / max(1, h - 1 - y0)
        row = a[y]
        sl = int(round(t * dl * (1 - k) * 0.9)); sr = int(round(t * dr * (1 - k) * 0.9))
        xi = np.arange(w)
        lm = (xi < cx) & (row[:, 3] > 0); rm = (xi >= cx) & (row[:, 3] > 0)
        nx = np.clip(xi[lm] + sl, 0, w - 1); left[y, nx] = row[lm]
        nx = np.clip(xi[rm] - sr, 0, w - 1); right[y, nx] = row[rm]
    res = Image.fromarray(out, 'RGBA')
    res.alpha_composite(Image.fromarray(left, 'RGBA'))
    res.alpha_composite(Image.fromarray(right, 'RGBA'))
    res.alpha_composite(Image.fromarray(np.where((np.arange(h) < y0)[:, None, None], a, 0).astype(np.uint8), 'RGBA'))
    return res

def stand_legs(img, hip=0.7):
    """Pose parada de frente/costas: copia a perna que está apoiada no chão para o outro lado (espelhada)."""
    a = np.asarray(img).copy(); h, w = a.shape[:2]; y0 = int(h * hip)
    al = a[..., 3] > 40
    xs = np.nonzero(al[max(0, y0 - 6):y0].any(0))[0]
    if not len(xs): return img
    cx = (xs.min() + xs.max()) / 2
    band = al[y0:]
    xi = np.arange(w)
    def lowest(mask_cols):
        ys = np.nonzero(band[:, mask_cols].any(1))[0]
        return ys.max() if len(ys) else -1
    left_low = lowest(xi < cx); right_low = lowest(xi >= cx)
    keep_left = left_low >= right_low
    half = int(np.ceil(max(cx, w - cx))) + 1
    W2 = 2 * half; off = int(round(half - cx))
    out = np.zeros((h, W2, 4), np.uint8)
    out[:, off:off + w] = a
    legs = out[y0:].copy()
    mid = half
    if keep_left:
        src = legs[:, :mid]; legs[:, mid:mid + src.shape[1]][:, ::-1][:] = 0
        legs[:, mid:] = src[:, ::-1][:, :W2 - mid]
    else:
        src = legs[:, mid:]; legs[:, :mid] = src[:, ::-1][:, src.shape[1] - mid:] if src.shape[1] >= mid else np.pad(src[:, ::-1], ((0, 0), (mid - src.shape[1], 0), (0, 0)))
    out[y0:] = legs
    return Image.fromarray(out, 'RGBA')

def mirror_legs(img, hip=0.7):
    """Mesma pose com a outra perna levantada: espelha só as pernas em volta do centro do tronco."""
    a = np.asarray(img); h, w = a.shape[:2]; y0 = int(h * hip)
    xs = np.nonzero((a[max(0, y0 - 6):y0, :, 3] > 40).any(0))[0]
    if not len(xs): return img
    cx = (xs.min() + xs.max()) / 2
    half = int(np.ceil(max(cx, w - cx))) + 1
    out = np.zeros((h, 2 * half, 4), np.uint8)
    off = int(round(half - cx)); out[:, off:off + w] = a
    out[y0:] = out[y0:, ::-1]
    return Image.fromarray(out, 'RGBA')
def foot_gap(img, hip=0.7):
    """Diferença de altura entre os dois pés (quanto maior, mais clara a passada)."""
    a = np.asarray(img); h, w = a.shape[:2]; y0 = int(h * hip)
    al = a[y0:, :, 3] > 40
    xs = np.nonzero((a[max(0, y0 - 6):y0, :, 3] > 40).any(0))[0]
    if not len(xs): return 0
    cx = int((xs.min() + xs.max()) / 2)
    def low(m):
        ys = np.nonzero(m.any(1))[0]
        return ys.max() if len(ys) else 0
    return abs(low(al[:, :cx]) - low(al[:, cx:]))
def step_cycle(frames, stand):
    """Passada de frente/costas: parado → pé esquerdo → parado → pé direito."""
    best = max(frames, key=foot_gap)
    best = lift_raised_foot(stand_legs_center(best))
    return [stand, best, stand, mirror_legs(best)]
def lift_raised_foot(img, hip=0.7, extra=0.05):
    """Deixa a passada mais visível: sobe um pouco mais a perna que já está no ar."""
    a = np.asarray(img).copy(); h, w = a.shape[:2]; y0 = int(h * hip); cx = w // 2
    al = a[y0:, :, 3] > 40
    def low(m):
        ys = np.nonzero(m.any(1))[0]
        return ys.max() if len(ys) else 0
    raised_left = low(al[:, :cx]) < low(al[:, cx:])
    cols = slice(0, cx) if raised_left else slice(cx, w)
    d = max(1, int(h * extra))
    part = a[y0:, cols].copy()
    a[y0:, cols] = 0
    # a coxa fica presa ao quadril; só a parte de baixo sobe
    k = (h - y0) // 3
    a[y0:y0 + k, cols] = part[:k]
    a[y0 + k - d:h - d, cols] = np.where(part[k:, :, 3:4] > 0, part[k:], a[y0 + k - d:h - d, cols])
    return Image.fromarray(a, 'RGBA')
def stand_legs_center(img, hip=0.7):
    a = np.asarray(img); h, w = a.shape[:2]; y0 = int(h * hip)
    xs = np.nonzero((a[max(0, y0 - 6):y0, :, 3] > 40).any(0))[0]
    if not len(xs): return img
    cx = (xs.min() + xs.max()) / 2
    half = int(np.ceil(max(cx, w - cx))) + 1
    out = Image.new('RGBA', (2 * half, h), (0, 0, 0, 0)); out.alpha_composite(img, (int(round(half - cx)), 0))
    return out

def center_on_torso(img, hip=0.6):
    a = np.asarray(img); h, w = a.shape[:2]; y0 = int(h * hip)
    xs = np.nonzero((a[max(0, y0 - 6):y0, :, 3] > 40).any(0))[0]
    if not len(xs): return img
    cx = (xs.min() + xs.max()) / 2
    half = int(max(cx, w - cx)) + 1
    out = Image.new('RGBA', (2 * half, h), (0, 0, 0, 0))
    out.alpha_composite(img, (int(round(half - cx)), 0))
    return out
def side_cycle(a, b):
    A, B = center_on_torso(a), center_on_torso(b)
    frames = [A, close_legs(A, 0.55), close_legs(A, 0.1), close_legs(B, 0.55),
              B, close_legs(B, 0.55), close_legs(B, 0.1), close_legs(A, 0.55)]
    return close_legs(A, 0.1), frames

# ---- Textura da água (img25 é a mesma peça repetida 2 × 2: usa um quarto e alisa as emendas)
_agua = Image.open(os.path.join(ROOT, 'tools', 'sprites-src', 'img25_agua.jpg')).convert('RGBA').crop((0, 0, 1024, 1024))
S['water_tex'] = seamless(_agua).resize((256, 256), Image.LANCZOS)

# ---- Personagens jogáveis. Cada um: parado e andando de frente, de costas e de lado (direita),
# mais duas poses de golpe. Nomes no atlas: <id>_<vista>_idle, <id>_<vista>_walk_<n>, <id>_swing_up, <id>_swing_side
# Folhas novas (img21 a img24): grade de 6 colunas × 4 linhas
GX = [0, 405, 860, 1288, 1717, 2171, 2576]
GY = [0, 351, 702, 1054, 1405]
def cell(c, r):
    return (GX[c] + 6, GY[r] + 6, GX[c + 1] - 6, GY[r + 1] - 6)
def standard(sheet, strides, swings):
    return (sheet, {
        'front_idle': cell(0, 0), 'front_walk': [cell(c, 0) for c in range(1, 6)],
        'back_idle': cell(0, 1), 'back_walk': [cell(c, 1) for c in range(1, 6)],
        'side_strides': strides,
        'swing_front': cell(swings[0], 3), 'swing_up': cell(swings[1], 3), 'swing_side': cell(swings[2], 3)})
PLAYERS = {   # passadas de lado: duas células da linha 3 usadas como pernas abertas
    'menino': standard('img21_davi', [cell(3, 2), cell(5, 2)], (0, 1, 3)),
    'menino_negro': standard('img23_caio', [cell(0, 2), cell(2, 2)], (0, 1, 3)),
    'menina_ruiva': standard('img22_clara', [cell(0, 2), cell(2, 2)], (0, 1, 3)),
    'menina_negra': standard('img24_ayo', [cell(0, 2), cell(2, 2)], (0, 1, 3)),
}
PLAYER_PX = 104
# Skins: qualquer folha tools/sprites-src/skin_<nome>.(jpg|png) no mesmo formato das folhas dos
# personagens (6 colunas × 4 linhas: frente, costas, lado, golpes) vira o visual "sk_<nome>".
import glob
def load_sheet(path):
    im = Image.open(path)
    if im.mode in ('RGBA', 'LA', 'P'):
        im = im.convert('RGBA'); bg = Image.new('RGBA', im.size, (255, 0, 255, 255)); bg.alpha_composite(im); im = bg
    return im.convert('RGB')
def detect_grid(img, cols=6, rows=4):
    """Acha as linhas da grade: faixas finas mais escuras que o fundo que atravessam a folha.
    Para cada posição esperada (divisão por igual) escolhe a linha mais forte por perto."""
    a = np.asarray(img).astype(float)
    lum = 0.3 * a[..., 0] + 0.59 * a[..., 1] + 0.11 * a[..., 2]
    bg = np.percentile(lum, 70)
    line = lum < bg * 0.6
    def pick(profile, n, size):
        hot = profile > 0.3
        cands, k = [], 0
        while k < size:
            if hot[k]:
                j = k
                while j < size and hot[j]: j += 1
                if j - k <= max(8, size * 0.008): cands.append(((k + j) / 2, profile[k:j].max()))   # só faixas finas
                k = j
            else: k += 1
        out, step = [0], size / n
        for e in [i * step for i in range(1, n)]:
            near = [(sc - 0.35 * abs(c - e) / step, c) for c, sc in cands if abs(c - e) < step * 0.5 and c > out[-1] + step * 0.4]
            out.append(int(max(near)[1]) if near else int(e))
        return out + [size]
    h, w = lum.shape
    return pick(line.mean(0), cols, w), pick(line.mean(1), rows, h)
# folhas em que a 1ª linha termina com quadros de costas: só os primeiros N são de frente
SKIN_ACENO = {'raposa', 'elfo_vermelho', 'elfo_verde', 'aprendiz', 'maga_prata', 'mago_noturno', 'vampiro', 'pinguim_chapeu',
              'pinguim_jaqueta', 'pinguim_gravata', 'armadura_estelar', 'husky'}   # 5ª pose da última linha é um aceno
SKIN_FRENTE = {'elfo_vermelho': 4, 'elfo_verde': 4, 'aprendiz': 4, 'maga_prata': 4, 'mago_noturno': 4,
               'husky': 4, 'pinguim_jaqueta': 4, 'pinguim_gravata': 5}
for path in sorted(glob.glob(os.path.join(ROOT, 'tools', 'sprites-src', 'skin_*.*'))):
    name = os.path.splitext(os.path.basename(path))[0]
    sid = 'sk_' + name[5:]
    im = load_sheet(path); xs, ys = detect_grid(im)
    IMG_IDS[name] = 200 + len(IMG_IDS); IM[IMG_IDS[name]] = im
    cl = lambda c, r, xs=xs, ys=ys: (xs[c] + 8, ys[r] + 8, xs[c + 1] - 8, ys[r + 1] - 8)
    PLAYERS[sid] = (name, {
        'front_idle': cl(0, 0), 'front_walk': [cl(c, 0) for c in range(1, SKIN_FRENTE.get(name[5:], 6))],
        'back_idle': cl(0, 1), 'back_walk': [cl(c, 1) for c in range(1, 6)],
        'side_strides': [cl(0, 2), cl(2, 2)],
        'swing_front': cl(0, 3), 'swing_up': cl(1, 3), 'swing_side': cl(0, 2), 'swing_maos_side': cl(3, 3),
        **({'swing_aceno': cl(4, 3)} if name[5:] in SKIN_ACENO else {})})   # o golpe de lado das folhas costuma vir com outro personagem
    print('skin:', sid)
def meia_mao(up, idle, costas=False):
    """Junta o lado do braço erguido (quadro de mãos para cima) com o outro lado do quadro parado.
    Alinha os dois pelos pés (centro das pernas) e corta no meio do corpo."""
    def centro(im):
        a = np.asarray(im)[..., 3] > 40
        h = a.shape[0]; low = a[int(h * 0.65):]
        xs = np.nonzero(low)[1]
        return xs.mean() if len(xs) else im.width / 2
    cu, ci = centro(up), centro(idle)
    W = int(max(cu, ci) + max(up.width - cu, idle.width - ci)) + 2
    H = max(up.height, idle.height)
    ox = max(cu, ci)
    A = Image.new('RGBA', (W, H)); A.alpha_composite(up, (int(round(ox - cu)), H - up.height))
    B = Image.new('RGBA', (W, H)); B.alpha_composite(idle, (int(round(ox - ci)), H - idle.height))
    cut_x = int(round(ox))
    out = B.copy()
    # de frente o braço erguido é o da esquerda da tela; de costas, o da direita (a mesma mão do personagem)
    box = (0, 0, cut_x, H) if not costas else (cut_x, 0, W, H)
    out.paste(A.crop(box), box[:2])
    return out.crop(out.getbbox())

for pid, (sheet, poses) in PLAYERS.items():
    if sheet not in IMG_IDS:
        IMG_IDS[sheet] = 200 + len(IMG_IDS); IM[IMG_IDS[sheet]] = load_sheet(os.path.join(ROOT, 'tools', 'sprites-src', sheet + '.jpg'))
    crops = {}
    for pose, b in poses.items():
        if pose == 'side_strides':
            idle, frames = side_cycle(*[cut(IMG_IDS[sheet], bb, keep_largest=True) for bb in b])
            crops['side_idle'] = idle
            for k, f in enumerate(frames): crops[f'side_walk_{k}'] = f
        elif pose in ('front_walk', 'back_walk') and 'side_strides' in poses:
            view = pose.split('_')[0]
            stand = stand_legs(cut(IMG_IDS[sheet], poses[view + '_idle'], keep_largest=True), 0.7)
            frames = step_cycle([cut(IMG_IDS[sheet], bb, keep_largest=True) for bb in b], stand)
            for k, f in enumerate(frames): crops[f'{pose}_{k}'] = f
        elif isinstance(b, list):
            for k, bb in enumerate(b): crops[f'{pose}_{k}'] = cut(IMG_IDS[sheet], bb, keep_largest=True)
        elif pose in ('front_idle', 'back_idle'):
            crops[pose] = stand_legs(cut(IMG_IDS[sheet], b, keep_largest=True), 0.7)   # os dois pés no chão
        else: crops[pose] = cut(IMG_IDS[sheet], b, keep_largest=True)
    # gesto de uma mão erguida: metade do quadro de braços para cima + metade do quadro parado
    for up, idle in (('swing_front', 'front_idle'), ('swing_up', 'back_idle')):
        if up in crops and idle in crops: crops[up.replace('swing_', 'swing_um_').replace('_up', '_back')] = meia_mao(crops[up], crops[idle], idle == 'back_idle')
    ref = max(c.height for n, c in crops.items() if not n.startswith('swing'))   # mesma escala em todos os quadros
    sc = PLAYER_PX / ref
    for n, c in crops.items():
        S[f'{pid}_{n}'] = c.resize((max(1, round(c.width * sc)), max(1, round(c.height * sc))), Image.LANCZOS)

# ---- Animais em 4 direções (folhas img10 a img18). A esquerda é o lado espelhado no jogo.
# Todos os quadros de um animal usam a mesma escala, para ele não mudar de tamanho ao virar.
def src(name):
    return Image.open(os.path.join(ROOT, 'tools', 'sprites-src', name + '.jpg')).convert('RGB')
ANIMALS = {
    'galinha': ('img10_galinha', {
        'front': [(113, 53, 347, 394), (606, 53, 848, 394), (1087, 53, 1330, 394), (1558, 53, 1800, 394)],
        'back': [(124, 524, 333, 866), (634, 524, 838, 867), (1107, 524, 1318, 867), (1588, 524, 1790, 866)],
        'side': [(83, 1025, 377, 1319), (585, 1025, 886, 1318), (1066, 1025, 1369, 1320), (1547, 1025, 1852, 1320)]}),
    'coelho': ('img11_coelho', {
        'front': [(156, 52, 357, 460), (657, 52, 869, 460), (1179, 52, 1381, 461), (1701, 52, 1893, 460)],
        'back': [(155, 524, 357, 982), (667, 524, 869, 982), (1179, 524, 1381, 982), (1691, 524, 1893, 982)],
        'side': [(63, 1067, 449, 1464), (575, 1066, 961, 1464), (1087, 1067, 1473, 1443), (1588, 1067, 1975, 1464)]}),
    'pintinho': (None, {
        'front': [('img13_pintinho_frente_costas', (94, 94, 429, 553))],
        'back': [('img13_pintinho_frente_costas', b) for b in [(74, 1091, 438, 1525), (596, 1088, 919, 1534), (1097, 1090, 1462, 1525), (1641, 1089, 1964, 1534)]],
        'side': [('img12_pintinho', b) for b in [(12, 44, 222, 294), (288, 45, 498, 298), (564, 44, 774, 294), (840, 45, 1050, 297)]]}),
    'raposa': ('img15_raposa', {
        'front': [(43, 31, 388, 481), (555, 31, 911, 481), (1067, 31, 1423, 481), (1579, 31, 1914, 481)],
        'back': [(136, 544, 375, 992), (637, 544, 888, 992), (1160, 544, 1399, 992), (1651, 544, 1912, 992)],
        'side': [(1, 1117, 511, 1443), (513, 1117, 1024, 1443), (1015, 1117, 1535, 1443), (1527, 1117, 2037, 1443)]}),
    'cervo': ('img16_cervo', {
        'front': [(134, 31, 378, 480), (656, 31, 900, 480), (1158, 31, 1412, 481), (1670, 32, 1914, 480)],
        'back': [(134, 543, 378, 992), (646, 543, 890, 992), (1158, 543, 1402, 992), (1670, 543, 1914, 992)],
        'side': [(42, 1045, 501, 1494), (534, 1045, 1013, 1494), (1046, 1045, 1525, 1494), (1557, 1045, 2037, 1494)]}),
    'pavao': ('img17_pavao', {
        'front': [(169, 51, 343, 452), (681, 59, 855, 452), (1193, 51, 1367, 454)],
        'back': [(169, 531, 344, 972), (680, 530, 880, 955), (1192, 531, 1368, 955), (1703, 530, 1925, 955)],
        'side': [(33, 1084, 472, 1446), (532, 1085, 985, 1436), (1039, 1085, 1495, 1435), (1547, 1085, 2002, 1436)],
        'fan': [(1, 1568, 511, 2003), (513, 1568, 1024, 2003), (1025, 1568, 1535, 2003), (1537, 1568, 2047, 2003)]}),
    'javali': ('img18_javali', {
        'front': [(47, 33, 197, 238), (324, 33, 489, 238), (600, 32, 764, 238), (893, 32, 1043, 238)],
        'back': [(51, 299, 208, 511), (327, 299, 485, 513), (617, 304, 767, 513), (893, 304, 1027, 511)],
        'side': [(2, 608, 262, 784), (281, 608, 540, 785), (557, 608, 818, 785), (836, 600, 1097, 790)]}),
}
ANIMAL_PX = 100   # altura, no atlas, do quadro mais alto de cada animal
n_img = 100
for kind, (default_src, views) in ANIMALS.items():
    crops = {}
    for view, boxes in views.items():
        for k, b in enumerate(boxes):
            name, box = (b if isinstance(b[0], str) else (default_src, b))
            if name not in IMG_IDS:
                n_img += 1; IMG_IDS[name] = n_img; IM[n_img] = src(name)
            crops[(view, k)] = cut(IMG_IDS[name], box, keep_largest=True)
    ref = max(c.height for (v, _), c in crops.items() if v != 'fan')
    sc = ANIMAL_PX / ref
    for (view, k), c in crops.items():
        S[f'{kind}_{view}_{k}'] = c.resize((max(1, round(c.width * sc)), max(1, round(c.height * sc))), Image.LANCZOS)

# ---- Compradores (imagem 7)
npc = {'tiao': [(55, 29, 284, 342), (534, 29, 763, 342)],
       'ana': [(999, 33, 1206, 338), (1383, 33, 1593, 337)],
       'lia': [(1803, 30, 2015, 339), (2258, 30, 2474, 339)]}
for name, boxes in npc.items():
    for f, b in enumerate(boxes):
        S[f'{name}_{f}'] = fit(cut(7, b, keep_largest=True), 80, 104)
S['lia_back'] = fit(cut(7, (1846, 1069, 2043, 1391), keep_largest=True), 80, 104)

# ---- Ícones (imagem 8)
icons = {'picareta': (54, 48, 327, 313), 'machado': (440, 42, 730, 315), 'espada': (1370, 37, 1638, 316),
         'muro': (1812, 20, 2106, 331), 'rede': (2235, 42, 2509, 305), 'sementes': (75, 441, 305, 614),
         'enxada': (534, 423, 714, 640), 'colheita': (953, 374, 1188, 690), 'carne': (1370, 445, 1631, 632),
         'madeira': (2246, 418, 2540, 652), 'pedra': (467, 752, 768, 1008), 'carvao': (946, 751, 1208, 1008),
         'bronze': (1329, 772, 1653, 990), 'ferro': (1775, 772, 2099, 990), 'ouro': (2224, 772, 2544, 990),
         'prata': (23, 1127, 342, 1343), 'petroleo': (1866, 1094, 2046, 1368), 'diamante': (2285, 1141, 2497, 1325)}
for name, b in icons.items():
    S[f'icon_{name}'] = fit(cut(8, b, keep_largest=True), 56, 56)

# ---- Monta o atlas (prateleiras)
# ---- Pontos de pegada: onde fica a mão em cada pose do jogador e o cabo/ponta de cada ferramenta
META = {}
def hand_point(img, side):
    """Mão na borda da silhueta (frente: lado esquerdo da imagem; costas e lado: direito), um pouco para dentro."""
    a = np.asarray(img); h, w = a.shape[:2]; al = a[..., 3] > 60
    best = None
    for y in range(int(h * 0.42), int(h * 0.72)):
        xs = np.nonzero(al[y])[0]
        if not len(xs): continue
        x = xs.min() if side == 'L' else xs.max()
        if best is None or (x < best[0] if side == 'L' else x > best[0]) or (abs(x - best[0]) <= 2 and y > best[1]):
            best = (x, y)
    if not best: return [int(w // 2), int(h * 0.6)]
    inward = max(2, round(w * 0.05))
    return [int(best[0] + (inward if side == 'L' else -inward)), int(best[1] - inward)]
def skin_color(img, pt):
    """Cor da mão (para desenhar os dedos fechados sobre o cabo)."""
    a = np.asarray(img).astype(int); h, w = a.shape[:2]; x, y = pt
    pts = a[max(0, y - 4):y + 5, max(0, x - 4):x + 5].reshape(-1, 4)
    pts = pts[pts[:, 3] > 200][:, :3]
    if not len(pts): return [210, 160, 120]
    lum = pts.sum(1); pts = pts[lum >= np.percentile(lum, 40)]   # evita contorno escuro
    return [int(v) for v in np.median(pts, 0)]
def fist_point(img, side, skin):
    """Centro do punho: pixels da cor da pele na altura do quadril, do lado em que a mão fica."""
    a = np.asarray(img).astype(int); h, w = a.shape[:2]; al = a[..., 3] > 180
    m = al & (np.sqrt(((a[..., :3] - np.array(skin)) ** 2).sum(-1)) < 48)
    yy, xx = np.mgrid[0:h, 0:w]
    m &= (yy > h * 0.45) & (yy < h * 0.78)
    xs = np.nonzero(al[int(h * 0.5)])[0]
    if not len(xs): return None
    cx = (xs.min() + xs.max()) / 2; hw = (xs.max() - xs.min()) / 2
    m &= (xx < cx - hw * 0.35) if side == 'L' else (xx > cx + hw * 0.35) if side == 'R' else (xx > cx - hw * 0.2)
    ys, xs2 = np.nonzero(m)
    if len(xs2) < 4: return None
    return [int(xs2.mean()), int(ys.mean())]
for pid in PLAYERS:
    n = pid + '_front_idle'
    if n in S: META['skin_' + pid] = skin_color(S[n], hand_point(S[n], 'L'))
for n, im in S.items():
    for pid in PLAYERS:
        if n.startswith(pid + '_') and not n.startswith(pid + '_swing') and n[len(pid) + 1:].split('_')[0] in ('front', 'back', 'side'):
            if n.startswith('menino_negro') and pid == 'menino': continue
            side = 'L' if '_front_' in n else 'R' if '_back_' in n else 'S'
            META['hand_' + n] = fist_point(im, side, META['skin_' + pid]) or hand_point(im, 'L' if side == 'L' else 'R')
# Capacete: tools/sprites-src/capacete.(jpg|png) com 3 desenhos lado a lado: frente, costas, lado (direita)
for ext in ('png', 'jpg'):
    hp_ = os.path.join(ROOT, 'tools', 'sprites-src', 'capacete.' + ext)
    if not os.path.exists(hp_): continue
    him = load_sheet(hp_); IMG_IDS['capacete'] = 300; IM[300] = him
    from scipy import ndimage as _ndi
    fg_ = ~key_mask(np.asarray(him)); fg_ = _ndi.binary_opening(fg_, iterations=2)
    lab_, _n = _ndi.label(_ndi.binary_dilation(fg_, iterations=8))
    boxes = sorted([(fg_[sl].sum(), sl) for sl in _ndi.find_objects(lab_)], key=lambda t: -t[0])[:3]
    boxes = sorted([sl for _, sl in boxes], key=lambda sl: sl[1].start)
    for view, sl in zip(('front', 'back', 'side'), boxes):
        c_ = cut(300, (sl[1].start, sl[0].start, sl[1].stop, sl[0].stop), keep_largest=True)
        S['helmet_' + view] = fit(c_, 64, 64)
    print('capacete: ok')
    break
def head_box(img):
    """Topo da cabeça e largura da cabeça (para encaixar o capacete). Procura só na faixa do meio,
    para os punhos erguidos nas poses de golpe não serem confundidos com a cabeça."""
    a = np.asarray(img); h, w = a.shape[:2]; al = a[..., 3] > 100
    mid = np.zeros_like(al); mid[:, int(w * 0.28):int(w * 0.72) + 1] = True
    rows = np.nonzero((al & mid).any(1))[0]
    if not len(rows): return [w // 2, 0, w // 2]
    top = int(rows[0]); y = min(h - 1, top + int(h * 0.1))
    xs = np.nonzero(al[y])[0]
    if not len(xs): return [w // 2, top, w // 3]
    # pedaço contínuo da linha que fica mais perto do centro (a cabeça), sem os braços
    runs = np.split(xs, np.nonzero(np.diff(xs) > 2)[0] + 1)
    run = min(runs, key=lambda r: abs((r[0] + r[-1]) / 2 - w / 2))
    hw = int(run[-1] - run[0])
    hw = min(hw, int(h * 0.3))
    return [int((run[0] + run[-1]) / 2), top, max(hw, int(h * 0.12))]
for n, im in S.items():
    for pid in PLAYERS:
        if n.startswith(pid + '_') and n[len(pid) + 1:].split('_')[0] in ('front', 'back', 'side', 'swing'):
            META['head_' + n] = head_box(im)
# Punho fechado (img26, fundo transparente), recolorido com a pele de cada personagem
_maos = Image.open(os.path.join(ROOT, 'tools', 'sprites-src', 'img26_maos.png')).convert('RGBA')
_fist = np.asarray(_maos.crop((64, 252, 163, 357))).astype(float)
_base_lum = 0.3 * 247 + 0.59 * 179 + 0.11 * 143
for pid in PLAYERS:
    sk = np.array(META.get('skin_' + pid, [220, 170, 130]), float)
    lum = (0.3 * _fist[..., 0] + 0.59 * _fist[..., 1] + 0.11 * _fist[..., 2]) / _base_lum
    out = _fist.copy(); out[..., :3] = np.clip(sk * lum[..., None], 0, 255)
    S['fist_' + pid] = Image.fromarray(out.astype(np.uint8), 'RGBA').resize((40, 42), Image.LANCZOS)
def grip_points(img):
    """Ponta do cabo e ponta da cabeça da ferramenta, pelo eixo principal dos pixels."""
    a = np.asarray(img); ys, xs = np.nonzero(a[..., 3] > 80)
    if len(xs) < 10: return None
    P = np.stack([xs, ys], 1).astype(float); c = P.mean(0)
    _, _, vt = np.linalg.svd(P - c, full_matrices=False); ax = vt[0]
    t = (P - c) @ ax; lo, hi = t.min(), t.max(); L = hi - lo
    perp = np.abs((P - c) @ np.array([-ax[1], ax[0]]))
    wlo = perp[t < lo + 0.25 * L].mean(); whi = perp[t > hi - 0.25 * L].mean()
    if wlo > whi: ax, lo, hi, t = -ax, -hi, -lo, -t     # o cabo é a ponta mais fina
    end = c + ax * lo; tip = c + ax * hi
    def on_handle(f):
        """Centro dos pixels do próprio cabo naquela altura (o eixo médio passa fora do cabo por causa da cabeça)."""
        t0 = lo + f * L; sel = np.abs(t - t0) < max(1.5, 0.04 * L)
        return P[sel].mean(0) if sel.any() else end + (tip - end) * f
    g30 = on_handle(0.3); g12 = on_handle(0.12)
    return [round(float(v), 1) for v in (g30[0], g30[1], tip[0], tip[1], g12[0], g12[1])]
for t in ['picareta', 'machado', 'enxada', 'espada', 'rede']:
    g = grip_points(S['icon_' + t])
    if g: META['grip_' + t] = g

# Robô minerador (vai no atlas principal, junto dos personagens) e construções (atlas próprio)
import build_structures
S.update(build_structures.robot_frames())
S.update(build_structures.weapon_frames())
S.update(build_structures.mob_frames())
S.update(build_structures.fx_frames())
S.update(build_structures.farmer_frames())
S.update(build_structures.evento_frames())
build_structures.pack_and_write(build_structures.build())

names = sorted(S, key=lambda n: -S[n].height)
AW, pad = 2048, 2
x = y = shelf = 0
pos = {}
for n in names:
    im = S[n]
    if x + im.width + pad > AW:
        x = 0; y += shelf + pad; shelf = 0
    pos[n] = [x, y, im.width, im.height]
    x += im.width + pad; shelf = max(shelf, im.height)
AH = y + shelf
atlas = Image.new('RGBA', (AW, AH), (0, 0, 0, 0))
for n, (px, py, w, h) in pos.items():
    atlas.paste(S[n], (px, py), S[n])
atlas.save(os.path.join(ROOT, 'tools', 'atlas-preview.png'), optimize=True)
atlas.save(os.path.join(ROOT, 'assets', 'atlas.webp'), quality=90, method=6)
json.dump(pos, open(os.path.join(ROOT, 'tools', 'atlas.json'), 'w'), separators=(',', ':'))

# Folha de conferência sobre fundo escuro e claro
prev = Image.new('RGBA', (AW, AH), (40, 34, 30, 255))
prev.alpha_composite(atlas)
pass
print('atlas', AW, AH, len(pos), 'sprites')

# Atualiza o mapa do atlas dentro do game.js
import re
gp = os.path.join(ROOT, 'game.js')
g = open(gp, encoding='utf-8').read()
g = re.sub(r'/\*ATLAS_MAP\*/.*?/\*FIM_ATLAS\*/', '/*ATLAS_MAP*/' + json.dumps({**pos, **META}, separators=(',', ':')) + '/*FIM_ATLAS*/', g, flags=re.S)
open(gp, 'w', encoding='utf-8').write(g)
print('game.js atualizado')
