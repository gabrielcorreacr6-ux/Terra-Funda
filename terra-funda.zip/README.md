# Terra Funda

Jogo 2D de mundo aberto, visto de cima, que mistura fazenda, construção e escavação em camadas. Esta é a **fase 1**: o protótipo solo que roda direto no navegador, sem instalar nada.

## O que já funciona

- **Contas de jogador** (Supabase): cadastro com nome de jogador, e-mail e senha, e recuperação de senha por e-mail. Cada jogador ganha um código único (ex.: `TF-7K2Q9M`), mostrado no Menu; a equipe busca e bane por ele. O progresso fica salvo na conta e volta em qualquer aparelho.
- **Administrador e moderadores**: painel protegido pelo servidor. O admin é invisível para os jogadores, nomeia moderadores, bane, doa moedas e controla as jazidas. Moderadores só banem e desbanem; tudo fica registrado.
- **23 skins** só visuais na loja, de Comum a Lendária (de 1.400 a 17.500 moedas).
- **Construir** (ferramenta 5): muros de 5 materiais (paliçada, pedra, tijolo, reforçado e muralha de ferro) que se encaixam sozinhos, e portões que abrem quando você chega perto. Desmontar com a picareta devolve o material.
- **Casas prontas na loja**: casa de camponês, casa de pedra, casa tribal, saloon, castelo e domo alienígena. Dá para entrar pela porta e ver o interior.
- **Defesa e móveis**: 6 torres, 2 catapultas (lançam pedras que quebram rochas e derrubam árvores), armadilha de espinhos e 32 móveis; 24 deles com arte no estilo Habbo para o cômodo das casas.
- **Tudo é editável**: no painel Construir aparece tudo o que está construído por perto, com Guardar (para colocar em outro lugar) e Vender (devolve metade do preço). Casas guardadas levam os móveis junto.
- **Muros ajustáveis**: prévia antes de colocar (verde cabe, vermelho não) e, no painel Construir, os modos Mover, Girar (automático, deitado, em pé) e Remover (devolve o material).
- **Barra de ações**: com Construir na mão aparece uma barra: antes de colocar, Girar e Cancelar; de frente para algo construído, Mover, Girar, Guardar e Vender (muros: Mover, Girar, Remover).
- **Mochila**: tirar e colocar o capacete, descartar qualquer item comprado e jogar fora itens.
- **Presentear skins**: na loja, uma skin sua pode ser enviada a outro jogador pelo código dele (TF-…).
- **Neve**: o chão cavado na neve volta a ficar coberto 2 minutos depois.
- **Quem entra**: cada casa e fortaleza tem dono e regra de entrada (só eu, clã e aliados, aberta). Quem está dentro de uma casa não é visto de fora, e bichos e compradores não entram.
- **Entrar e decorar**: perto da porta aparece Entrar. Dentro, cada casa tem um cômodo próprio em losangos (15 × 15 na casa comum, 45 × 45 no castelo); em Decorar você escolhe a cor do chão e das paredes e coloca seus móveis onde quiser.
- **Arco e cetro mágico**: o arco caça de longe e gasta flechas; o cetro transforma você em mago: a magia atordoa animais (a rede pega na certa), recarrega sozinha e ilumina a noite.
- **Música e sons**: música medieval suave e sons de golpe, corte, escavação, pedra, moedas e magia, gerados pelo próprio jogo (liga e desliga no Menu).
- **Vida e combate**: 150 de vida, regenera fora de combate. Morrer leva você para casa e deixa um X (só seu) no lugar da última morte.
- **Experiência por arma** (espada, arco, cetro e livro, cada uma com a sua): Iniciante, Aprendiz, Médio, Grande, Expert e, só no cetro, Lendário. Cada nível muda dano, alcance, área, queimação e a cor da aura.
- **Saqueadores**: bandos de até 4, com um chefe mais forte, em acampamentos (o admin move, liga e desliga). Veem você a 5 blocos, perseguem até 12, roubam até 500 moedas e guardam no baú do acampamento. Voltam 8 min depois de morrer.
- **Bicho do petróleo**: guardião que cava perto das jazidas de petróleo; ataca a 3 blocos, persegue até 10, dá 100 moedas e volta 7 min depois se ainda houver petróleo.
- **Equipe**: teleporte pelo mapa, aura (moderador: verde; admin: vermelha, preta, roxa, verde ou dourada) e, para o admin, dar nível de arma a qualquer jogador.
- **Ajudante de fazenda**: colhe o trigo maduro em volta de onde foi colocado, guarda a colheita e replanta sozinho.
- **Inimigos com estratégia**: o bando inteiro avisa quando um vê você, cerca por lados diferentes e ataca dois de cada vez; o chefe dá investidas; o bicho do petróleo some debaixo da terra e sai do seu lado; todos ficam furiosos com pouca vida.
- **Chat de texto** (com as contas ligadas): barra minimizada no topo; abas Todos, Privado (por código TF-…, para um ou mais jogadores) e Amigos (em amarelo). A mensagem aparece num balão sobre a cabeça. Nada fica guardado. Tecla Enter ou T abre.
- **Robô minerador**: fica onde você colocar, tira minério de verdade das camadas de baixo e guarda para você buscar.
- **Desgaste das ferramentas**: as da loja (picaretas, machados, espadas, rede, capacete) acabam e precisam ser compradas de novo; as simples você faz de novo na Mochila com madeira e pedra.
- **Escolha de personagem**: Davi, Caio, Clara ou Ayo, escolhidos ao começar e trocados pelo Menu. Cada um tem caminhada nas 4 direções e poses de golpe.
- **Mundo grande em camadas**: 480 × 320 blocos, com superfície + 5 camadas subterrâneas, gerado aleatoriamente.
- **Seis biomas**, um por região: Floresta, Campos (início), Pântano, Deserto, Montanhas e Neve. Cada um muda árvores, pedras, água, animais, crescimento das plantações e profundidade dos minérios.
- **Jazidas**: prata, ouro, petróleo e diamante só existem em jazidas definidas, que podem ser movidas, pausadas e repostas.
- **Escavação**: a picareta minera pedras e minérios em vários golpes (de 2 na pedra a 7 no diamante; cada picareta melhor tira um golpe); `F` cava um buraco e desce uma camada. Em cima da escada, `F` sobe.
- **Árvores grandes e mudas**: uma árvore adulta pede 6 golpes (4 com machado de bronze, 2 com o de ferro), dá 5 madeiras e deixa uma muda que volta a crescer.
- **Recursos finitos por profundidade**: carvão, bronze e ferro em todas as regiões; os minérios das jazidas exigem picaretas melhores.
- **Água que escorre**: cave uma vala da lagoa até onde quiser e a água segue o caminho. Se a vala chegar a um buraco, a água cai e inunda o túnel de baixo.
- **Fazenda**: ara com a enxada, planta e colhe. Plantas com água ao lado crescem bem mais rápido. Terra arada abandonada volta a ser grama.
- **Caça e captura**: a espada abate (carne) e a rede captura animais vivos, que valem mais. Raposas (noite), cervos (perto de água), pavões (raros, fogem) e um javali dourado lendário que surge em noites raras. Catálogo com recompensa ao completar.
- **Animais em 4 direções**: galinhas (algumas com pintinhos atrás), coelhos, raposas, cervos, pavões (abrem a cauda quando param) e o javali dourado. Pintinhos não podem ser caçados, só capturados com a rede.
- **Compradores no mapa**: Tião (minérios e madeira), Dona Ana (colheitas e carne) e Lia (animais vivos) andam pelo mundo, acampam e mudam de lugar. Setas na borda da tela mostram onde estão.
- **Loja**: compre sementes, picaretas, machados, capacete com lanterna e rede de captura.
- **Dia e noite**: um dia completo dura 10 minutos; à noite e no subsolo a visão fica limitada à luz ao redor.
- **Casa e mochila**: defina sua casa pelo Menu e volte a ela com o botão Casa (3 s parado, espera de 5 min). O botão Mochila mostra equipamentos, itens e o catálogo.
- **Salvamento automático** no navegador a cada 15 segundos.
- **Celular**: controles na tela (direcional, Usar e Descer).

## Controles

| Ação | Teclado | Celular |
| --- | --- | --- |
| Andar | `WASD` ou setas | Direcional |
| Usar ferramenta | `Espaço` (segure para repetir) | Usar |
| Descer / subir | `F` | Descer / Subir |
| Trocar ferramenta | `1`–`6`, `Q` / `E` | Toque na barra |
| Arco / cetro (depois de comprar) | `7` / `8` | Barra |
| Mãos livres | `9` | Último espaço da barra |
| Mochila | `I` | Mochila |
| Voltar para casa | `H` | Casa |
| Escolher o que construir | `R` | Toque de novo em Construir |
| Loja | `B` | Loja |

## Ligar as contas (Supabase)

Sem esta etapa o jogo funciona normalmente, só que salvo apenas no navegador e sem cadastro.

1. Crie uma conta grátis em [supabase.com](https://supabase.com) e clique em **New project**.
2. No projeto, abra **SQL Editor**, cole todo o conteúdo de `supabase/schema.sql` e clique em **Run**. Isso cria as tabelas e as regras de segurança.
3. Em **Authentication → Providers → Email**, deixe o login por e-mail ligado. Se quiser testar sem confirmar e-mail, desligue **Confirm email** (religue antes de abrir o jogo ao público).
4. Em **Authentication → URL Configuration**, coloque o endereço do seu GitHub Pages em **Site URL** e também em **Redirect URLs** (ex.: `https://SEU-USUARIO.github.io/terra-funda/`). É para lá que os links de confirmar e-mail e de recuperar senha levam.
5. Em **Project Settings → API**, copie a **Project URL** e a chave pública (**publishable** ou **anon public**) e cole em `config.js`.
6. Abra o jogo, crie **a sua** conta e, no SQL Editor, rode (trocando o nome):

```sql
update public.profiles set role = 'admin' where username = 'SEU_NOME_NO_JOGO';
```

Pronto: no Menu aparece **Painel da equipe** só para você. Para nomear moderadores, use o próprio painel.

A chave "anon" fica visível no código, e isso é normal: quem protege os dados são as regras do banco. Nunca coloque a chave "service_role" no jogo.

## Como rodar

**No computador:** abra o `index.html` no navegador. Ou, se preferir um servidor local:

```bash
npx serve .
# ou
python3 -m http.server 8000
```

**No GitHub Pages (link para jogar no celular):**

1. Crie um repositório no GitHub e envie estes arquivos para ele (a raiz do repositório deve ter o `index.html`).
2. No repositório, vá em **Settings → Pages**.
3. Em **Source**, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`, e salve.
4. Em um ou dois minutos o jogo fica disponível em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.

Comandos para enviar pela primeira vez:

```bash
git init
git add .
git commit -m "Protótipo Terra Funda"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/terra-funda.git
git push -u origin main
```

## Estrutura

```
index.html               tela do jogo, HUD, loja e menus
config.js                endereço e chave pública do Supabase (vazio = só no navegador)
online.js                cadastro, login, salvamento na nuvem e ações da equipe
supabase/schema.sql      tabelas e regras de segurança do servidor
style.css                visual da interface
game.js                  todo o jogo: mundo, água, fazenda, animais, loja, luz e salvamento
assets/atlas.webp        personagens, animais, ícones, terreno e o robô
assets/estruturas.webp   muros, portões, torres, casas, fortalezas e móveis
tools/build_atlas.py     recorta as folhas de sprites e gera os dois atlas
tools/build_structures.py  recorte das folhas de construções (chamado pelo build_atlas.py)
tools/sprites-src/       folhas de sprites originais (fundo magenta)
```

## Arte

Os gráficos vêm de folhas de sprites com fundo magenta, guardadas em `tools/sprites-src/`. Para trocar ou adicionar arte, substitua as folhas e rode:

```bash
pip install pillow numpy scipy
python3 tools/build_atlas.py
```

**Skins** (só visual): salve a folha como `tools/sprites-src/skin_<id>.jpg` (ou `.png`), no mesmo formato das folhas dos personagens (6 colunas × 4 linhas: frente, costas, lado e golpes). Os ids, nomes, raridades e preços ficam na lista `SKINS` do `game.js`. Ao rodar o script, a skin aparece na loja.

**Construções**: as folhas `b_*.jpg` (muros, torres, cabana, pedra, tribal, saloon, castelo, domo, muralha, forte e colônia) e `npc_minerador.jpg` são recortadas por `tools/build_structures.py`, que guarda a posição de cada peça. Os nomes, tamanhos e preços ficam em `BUILDS` e `WALL_MATS` no `game.js`.

**Capacete**: salve `tools/sprites-src/capacete.png` (ou `.jpg`) com três desenhos lado a lado (frente, costas, lado virado para a direita). O jogo encaixa o capacete na cabeça de cada pose.

O script remove o fundo, recorta cada sprite, monta `assets/atlas.webp` e atualiza o mapa do atlas dentro do `game.js`. As posições de cada recorte ficam no próprio script. Se o atlas não carregar, o jogo usa os desenhos feitos por código.

Os ajustes principais ficam no topo do `game.js`: tamanho das regiões e do mapa (`REGION`, `RCOLS`, `RROWS`, `D`), biomas (`BIOMES`), jazidas (`DEPOSIT_PLAN`), duração do dia (`DAY_MS`), força das fontes de água (`SOURCE_LEVEL`) e velocidade do personagem (`SPEED`). Valores dos itens estão em `ITEMS` e os preços da loja em `SHOP`.

## Próximas fases

1. **Base solo** (este protótipo).
2. **Conteúdo**: ~~casas, muros, torres, móveis, robô minerador~~ (feitos); faltam guardas, ajudantes de plantio e colheita, tochas.
3. **Multiplayer**: mundo compartilhado em tempo real, clãs e doações entre jogadores (contas e painel da equipe já prontos).
4. **Combate**: armas, defesas automáticas, guardiões, saques de casas e skins visíveis para todos.

Detalhes completos no documento de projeto.
